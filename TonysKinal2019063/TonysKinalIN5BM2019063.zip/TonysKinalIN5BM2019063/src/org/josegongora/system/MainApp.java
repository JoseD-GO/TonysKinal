package org.josegongora.system;

import java.io.InputStream;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.fxml.JavaFXBuilderFactory;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import org.josegongora.controller.DatosPersonalesController;
import org.josegongora.controller.EmpleadoController;
import org.josegongora.controller.EmpresaController;
import org.josegongora.controller.MenuPrincipalController;
import org.josegongora.controller.PlatoController;
import org.josegongora.controller.PresupuestoController;
import org.josegongora.controller.ProductoController;
import org.josegongora.controller.ProductoHasPlatoController;
import org.josegongora.controller.ServicioController;
import org.josegongora.controller.ServicioHasEmpleadoController;
import org.josegongora.controller.ServicioHasPlatoController;
import org.josegongora.controller.TipoEmpleadoController;
import org.josegongora.controller.TipoPlatoController;

public class MainApp extends Application {
    private final String PAQUETE_VISTA = "/org/josegongora/view/";
    private Stage escenarioPrincipal;
    private Scene escena;
    
    @Override
    public void start(Stage escenarioPrincipal) throws Exception {
        this.escenarioPrincipal = escenarioPrincipal;
        this.escenarioPrincipal.setTitle("Tony's KINAL App");
        escenarioPrincipal.getIcons().add(new Image("/org/josegongora/img/icono.png"));
        menuPrincipal();
        escenarioPrincipal.show();
    }
    public void menuPrincipal(){
        try{
            MenuPrincipalController menuPrincipal = (MenuPrincipalController)cambiarEscena("MenuPrincipalView.fxml",731,491);
            menuPrincipal.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void ventanaProgramador(){
        try{
            DatosPersonalesController datosPersonales = (DatosPersonalesController)cambiarEscena("DatosPersonalesView.fxml",600,400);
            datosPersonales.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void ventanaEmpresa(){
        try{
        EmpresaController empresaController = (EmpresaController)cambiarEscena("EmpresaView.fxml",1089,546);
        empresaController.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void ventanaPresupuesto(){
        try{
            PresupuestoController presupuestoController = (PresupuestoController)cambiarEscena("PresupuestoView.fxml",1089,546);
            presupuestoController.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void ventanaServicio(){
        try{
            ServicioController servicioController = (ServicioController)cambiarEscena("ServicioView.fxml",1089,546);
            servicioController.setEscenarioPrincipal(this);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void ventanaTipoEmpleado(){
        try {
            TipoEmpleadoController tipoE = (TipoEmpleadoController)cambiarEscena("TipoEmpleadoView.fxml", 1089, 546);
            tipoE.setEscenarioPrincipal(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void ventanaEmpleado(){
        try {
            EmpleadoController empleadoC = (EmpleadoController)cambiarEscena("EmpleadoView.fxml",1089,546);
            empleadoC.setEscenarioPrincipal(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void ventanaTipoPlato(){
        try {
            TipoPlatoController tipoPlato = (TipoPlatoController)cambiarEscena("TipoPlatoView.fxml",1089,546);
            tipoPlato.setEscenarioPrincipal(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void ventanaProducto(){
        try {
            ProductoController producto = (ProductoController)cambiarEscena("ProductoView.fxml",1089,546);
            producto.setEscenarioPrincipal(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void ventanaPlato(){
        try {
            PlatoController plato = (PlatoController)cambiarEscena("PlatoView.fxml", 1089, 546);
            plato.setEscenarioPrincipal(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void ventanaServicioHasPlato(){
        try {
            ServicioHasPlatoController servicioPlato = (ServicioHasPlatoController)cambiarEscena("ServicioHasPlatoView.fxml", 1089 , 546);
            servicioPlato.setEscenarioPrincipal(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void ventanaProductoHasPlato(){
        try {
            ProductoHasPlatoController productoPlato = (ProductoHasPlatoController)cambiarEscena("ProductosHasPlatoView.fxml",1089,546);
            productoPlato.setEscenariPrincipal(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void ventananServicioHasEmpleado(){
        try {
            ServicioHasEmpleadoController servicioEmpleado = (ServicioHasEmpleadoController)cambiarEscena("ServicioHasEmpleadoView.fxml",1089,546);
            servicioEmpleado.setEscenarioPrincipal(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
    
    public Initializable cambiarEscena(String fxml, int ancho, int alto) throws Exception{
    Initializable resultado = null;
    FXMLLoader cargadorFXML = new FXMLLoader();
    InputStream archivo = MainApp.class.getResourceAsStream(PAQUETE_VISTA+fxml);
    cargadorFXML.setBuilderFactory(new JavaFXBuilderFactory());
    cargadorFXML.setLocation(MainApp.class.getResource(PAQUETE_VISTA+fxml));
    escena = new Scene( (AnchorPane)cargadorFXML.load(archivo),ancho,alto);
    escenarioPrincipal.setScene(escena);
    escenarioPrincipal.sizeToScene();
    escenarioPrincipal.setResizable(false);
    escenarioPrincipal.centerOnScreen();
    resultado = (Initializable)cargadorFXML.getController();
    return resultado;
    
    }
    
}
