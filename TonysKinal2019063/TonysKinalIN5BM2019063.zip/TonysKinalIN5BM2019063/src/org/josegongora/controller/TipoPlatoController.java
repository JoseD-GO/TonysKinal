package org.josegongora.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import org.josegongora.bd.Conexion;
import org.josegongora.bean.TipoPlato;
import org.josegongora.system.MainApp;

public class TipoPlatoController implements Initializable {
    private MainApp escenarioPrincipal;
    
    private enum Operacion{NUEVO,GUARDAR,ELIMINAR,EDITAR,CARGAR,NINGUNO}
    
    private Operacion tipoOperacion = Operacion.NINGUNO;
    
    ObservableList<TipoPlato> listaTipoPlato;
    
    @FXML private TableView tblTipoPlato;
    
    @FXML private TableColumn colCodigoTipoPlato, colDescripcionTipo;
    
    @FXML private JFXTextField txtCodigoTipoPlato, txtDescripcion;
    
    @FXML private JFXButton btnGuardar, btnNuevo, btnEliminar, btnEditar, btnReporte, btnCancelar;
    
    @FXML private ImageView imgNuevo;
    
    @FXML private TextField txtBuscar;
    
    Alert informacion = new Alert(AlertType.INFORMATION); //Creando objetos de tipo Alert para utilizar en toda la clase
    Alert error = new Alert(AlertType.ERROR); //Creando objetos de tipo Alert para utilizar en toda la clase
    Alert confirmacion = new Alert(AlertType.CONFIRMATION); //Creando objetos de tipo Alert para utilizar en toda la clase
    
    public void cargarDatos(){
        tblTipoPlato.setItems(getTipoPlato());
        colCodigoTipoPlato.setCellValueFactory(new PropertyValueFactory<TipoPlato, Integer>("codigoTipoPlato"));
        colDescripcionTipo.setCellValueFactory(new PropertyValueFactory<TipoPlato, String>("descripcionTipo"));
        limpiarTF();
        tblTipoPlato.getSelectionModel().clearSelection();
    }
    
    public void seleccionTipoPlato(){
        tblTipoPlato.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<TipoPlato>(){
            @Override
            public void changed(ObservableValue<? extends TipoPlato> observable, TipoPlato valorAnterior, TipoPlato valorSeleccionado) {
                if(valorSeleccionado != null){
                    txtCodigoTipoPlato.setText(String.valueOf(valorSeleccionado.getCodigoTipoPlato()));
                    txtDescripcion.setText(valorSeleccionado.getDescripcionTipo());
                    desactivarBotones();
                    desactivarTF();
                }
            }
            
        }
        );
    }

    public ObservableList<TipoPlato> getTipoPlato(){
        ArrayList<TipoPlato> lista = new ArrayList<TipoPlato>();
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Listar_Tipo_Plato()}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new TipoPlato(resultado.getInt("codigoTipoPlato"),
                                        resultado.getString("descripcionTipo")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaTipoPlato = FXCollections.observableArrayList(lista);
    }
    
    public void btnNuevo(){
        switch(tipoOperacion){
            case NINGUNO:
                Image img = new Image(getClass().getResourceAsStream("/org/josegongora/img/cancelar.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(img);//Cambiando la imagen del boton nuevo
                btnGuardar.setDisable(true);
                btnNuevo.setText("Cancelar");
                activarTF();
                limpiarDos();
                tipoOperacion = Operacion.GUARDAR;
                break;
            case GUARDAR:
                Image imagen = new Image(getClass().getResourceAsStream("/org/josegongora/img/nuevo.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(imagen);//Cambiando la imagen del boton nuevo
                btnGuardar.setDisable(false);
                btnNuevo.setText("Nuevo");
                limpiarTF();
                desactivarTF();
                tipoOperacion = Operacion.NINGUNO;
                break;
        }
    }
    
    public void btnEditar(){
        switch(tipoOperacion){
            case NINGUNO:
                activarTF();
                btnReporte.setDisable(true);
                btnEliminar.setDisable(true);
                btnEditar.setText("Guardar");
                tipoOperacion = Operacion.EDITAR;
                break;
            case EDITAR:
                editarDato();
                btnEditar.setText("Editar");
                tipoOperacion = Operacion.NINGUNO;
                break;
        }
    }
    
    public void agregarDato(){
        TipoPlato registro = new TipoPlato();
        registro.setDescripcionTipo(txtDescripcion.getText());
        if(registro.getDescripcionTipo().equals("")){
            error.setTitle("Error");
            error.setHeaderText("Resultado");
            error.setContentText("El registro ha fallado!!\nFaltan datos por ingresar"); 
            error.show();
        }else{
            try {
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Agregar_Tipo_Plato(?)}");
                procedimiento.setString(1, registro.getDescripcionTipo());
                procedimiento.executeUpdate();
                listaTipoPlato.add(registro);
                if(registro != null){
                        informacion.setTitle("Registro Agregado");
                        informacion.setHeaderText("Resultado:");
                        informacion.setContentText("El registro se ha completado con exito!!");
                        informacion.show();
                        cargarDatos();
                }
                Image imagen = new Image(getClass().getResourceAsStream("/org/josegongora/img/nuevo.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(imagen);//Cambiando la imagen del boton nuevo
                btnNuevo.setText("Nuevo");
                tipoOperacion = Operacion.NINGUNO;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public void eliminarDato(){
        confirmacion.setTitle("Eliminar Registro");
        confirmacion.setHeaderText("¿Estas seguro de eliminar este registro?\nSe eliminarán todos los registros relacionados con el tipo de plato");
        confirmacion.setContentText("Código: "+txtCodigoTipoPlato.getText());
        Optional<ButtonType> opcion = confirmacion.showAndWait();
        if(opcion.get() == ButtonType.CANCEL){
            informacion.setTitle("Información");
            informacion.setHeaderText("Resultado:");
            informacion.setContentText("Se ha cancelado el proceso");
            informacion.show();
            cargarDatos();
        }else if(opcion.get() == ButtonType.OK){
            try {
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Eliminar_Tipo_Plato(?)}");
                procedimiento.setInt(1, Integer.parseInt(txtCodigoTipoPlato.getText()));
                int resultado = procedimiento.executeUpdate();
                if(resultado > 0){
                    informacion.setTitle("Eliminar Registro");
                    informacion.setHeaderText("Resultado");
                    informacion.setContentText("El registro ha sido eliminado");
                    informacion.show();
                    cargarDatos();
                }else{
                    error.setTitle("Error");
                    error.setHeaderText("Resultado");
                    error.setContentText("Error al intentar eliminar el registro!!!");
                    error.show();
                    cargarDatos();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public void editarDato(){
        if(txtDescripcion.getText().equals("")){
            error.setTitle("Error");
            error.setHeaderText("Resultado");
            error.setContentText("La modificación ha fallado!!\nFaltan datos por ingresar"); 
            error.show();
        }else{
            try {
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Actualizar_Tipo_Plato(?,?)}");
                procedimiento.setString(1, txtCodigoTipoPlato.getText());
                procedimiento.setString(2, txtDescripcion.getText());
                int modi = procedimiento.executeUpdate();
                if(modi > 0){
                    informacion.setTitle("Registro modificado");
                    informacion.setHeaderText("Resultado:");
                    informacion.setContentText("El registro se ha modificado con exito");
                    informacion.show();
                    cargarDatos();
                }else{
                    error.setTitle("Error");
                    error.setHeaderText("Resultado:");
                    error.setContentText("Error al intentar modificar el registro!!!");
                    error.show();
                    cargarDatos();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public TipoPlato buscarTipoPlato(int codigoTipoPlato){
        TipoPlato resultado = null;
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_Tipo_Plato(?)}");
            procedimiento.setInt(1, codigoTipoPlato);
            ResultSet registro = procedimiento.executeQuery();
            while(registro.next()){
                resultado = new TipoPlato(registro.getInt("codigoTipoPlato"),
                                      registro.getString("descripcionTipo"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }
    
    //Método para buscar datos
    public void buscarTipoPlato(){
        try {
            PreparedStatement pS = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_Tipo_Plato(?)}");
            pS.setString(1, txtBuscar.getText());
            ResultSet resultado = pS.executeQuery();
            if(resultado.next()){
                txtCodigoTipoPlato.setText(resultado.getString("codigoTipoPlato"));
                txtDescripcion.setText(resultado.getString("descripcionTipo"));
                desactivarBotones();
            }else{
                error.setTitle("ERROR");
                error.setHeaderText("Error:");
                error.setContentText("No existe un registro con código: "+txtBuscar.getText());
                error.show();
                txtBuscar.setText("");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    //Método para el bonton Cancelar
    public void btnCancelar(){
        txtCodigoTipoPlato.setText("");
        txtDescripcion.setText("");
        txtBuscar.setText(null);
        
        desactivarTF();
        
        btnGuardar.setDisable(true);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(false);
        btnNuevo.setDisable(false);
        
        btnCancelar.setVisible(false);
        
        btnEditar.setText("Editar");
        tipoOperacion = Operacion.NINGUNO;
        
        tblTipoPlato.getSelectionModel().clearSelection();
    }
    
        
    //Método para limpiar los TextField y para desactivar botones
    public void limpiarTF(){
        txtCodigoTipoPlato.setText("");
        txtDescripcion.setText("");
        txtBuscar.setText(null);
        
        btnGuardar.setDisable(true);
        btnReporte.setDisable(false);
        btnEliminar.setDisable(true);
        btnEditar.setDisable(true);
        btnNuevo.setDisable(false);
        
        btnCancelar.setVisible(false);
    }
    
    //Método para limpiar TextField pero con otras instrucciones
    public void limpiarDos(){
        txtCodigoTipoPlato.setText("");
        txtDescripcion.setText("");
        
        btnGuardar.setDisable(false);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(true);
    }
    
    //Método para activar TextField
    public void activarTF(){
        txtDescripcion.setEditable(true);
    }

    //Método para desactivar TextField
    public void desactivarTF(){
        txtDescripcion.setEditable(false);
    }
    
    //Método para desactivar Botones
    public void desactivarBotones(){
        btnGuardar.setDisable(true);
        btnEditar.setDisable(false);
        btnEliminar.setDisable(false);
        btnReporte.setDisable(true);
        btnNuevo.setDisable(true);
        
        btnCancelar.setVisible(true);
    }
    
    //Método para comprobar la conexion
    public void estadoConexion(){
        if(Conexion.getInstance().getConexion() != null){
            informacion.setTitle("Conexión");
            informacion.setHeaderText("Resultado");
            informacion.setContentText("Conexión exitosa!!!");
            informacion.show();
        }else{
            error.setTitle("Conexión");
            error.setHeaderText("Resultado");
            error.setContentText("Error de conexión");
            error.show();
        }
    
    }
    
    public void bloquearTamanioCol(){
        colCodigoTipoPlato.setResizable(false);
        colDescripcionTipo.setResizable(false);
        colCodigoTipoPlato.reorderableProperty().set(false);
        colDescripcionTipo.reorderableProperty().set(false);
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cargarDatos();
        seleccionTipoPlato();
        desactivarTF();
        bloquearTamanioCol();
    }
    
    public MainApp getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(MainApp escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
    
    public void menuPrincipal(){
        escenarioPrincipal.menuPrincipal();
    }
    
    public void ventanaPlato(){
        escenarioPrincipal.ventanaPlato();
    }
    
}
