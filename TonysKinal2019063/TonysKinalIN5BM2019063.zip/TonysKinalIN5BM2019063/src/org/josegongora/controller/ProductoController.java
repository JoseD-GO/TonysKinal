package org.josegongora.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import org.josegongora.bd.Conexion;
import org.josegongora.bean.Producto;
import org.josegongora.system.MainApp;

public class ProductoController implements Initializable{
    private enum Operacion{NUEVO,GUARDAR,ELIMINAR,EDITAR,CARGAR,NINGUNO}
    
    private Operacion tipoOperacion = Operacion.NINGUNO;
    
    private MainApp escenarioPrincipal;
    
    ObservableList<Producto> listaProducto;
    
    @FXML private TableView tblProducto;
    
    @FXML private TableColumn colCodigoProducto, colNombreProducto, colCantidadProducto;
    
    @FXML private JFXTextField txtCodigoProducto, txtNombreProducto, txtCantidadProducto;
    
    @FXML private TextField txtBuscar;
    
    @FXML private JFXButton btnNuevo, btnGuardar, btnReporte, btnEliminar, btnEditar, btnCancelar;
    
    @FXML private ImageView imgNuevo;

    Alert error = new Alert(AlertType.ERROR); //Creando objetos de tipo Alert para utilizar en toda la clase
    Alert informacion = new Alert(AlertType.INFORMATION);//Creando objetos de tipo Alert para utilizar en toda la clase
    Alert confirmacion  = new Alert(AlertType.CONFIRMATION);//Creando objetos de tipo Alert para utilizar en toda la clase
    
    public void cargarDatos(){
        tblProducto.setItems(getProducto());
        colCodigoProducto.setCellValueFactory(new PropertyValueFactory<Producto,Integer>("codigoProducto"));
        colNombreProducto.setCellValueFactory(new PropertyValueFactory<Producto, String>("nombreProducto"));
        colCantidadProducto.setCellValueFactory(new PropertyValueFactory<Producto, Integer>("cantidad"));
        tblProducto.getSelectionModel().clearSelection();
        limpiarTF();
    }
    
    public void seleccionProducto(){
        tblProducto.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Producto>(){
            @Override
            public void changed(ObservableValue<? extends Producto> observable, Producto valorAnterior, Producto valorSeleccionado) {
                if(valorSeleccionado != null){
                    txtCodigoProducto.setText(String.valueOf(valorSeleccionado.getCodigoProducto()));
                    txtNombreProducto.setText(valorSeleccionado.getNombreProducto());
                    txtCantidadProducto.setText(String.valueOf(valorSeleccionado.getCantidad()));
                    desactivarBotones();
                    desactivarTF();
                }
            }
            
        }
        );
    }
    
    public ObservableList<Producto> getProducto(){
        ArrayList<Producto> lista = new ArrayList<Producto>();
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Listar_Producto}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new Producto(resultado.getInt("codigoProducto"),
                                        resultado.getString("nombreProducto"),
                                        resultado.getInt("cantidad")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaProducto = FXCollections.observableArrayList(lista);
    }
    
    public void btnNuevo(){
        switch(tipoOperacion){
            case NINGUNO:
                Image img = new Image(getClass().getResourceAsStream("/org/josegongora/img/cancelar.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(img);//Cambiando la imagen del boton nuevo 
                btnNuevo.setText("Cancelar");
                btnGuardar.setDisable(true);
                activarTF();
                limpiarDos();
                tipoOperacion = Operacion.GUARDAR;
                break;
            case GUARDAR:
                Image imagen = new Image(getClass().getResourceAsStream("/org/josegongora/img/nuevo.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(imagen);//Cambiando la imagen del boton nuevo 
                btnNuevo.setText("Nuevo");
                btnGuardar.setDisable(false);
                limpiarTF();
                desactivarTF();
                tipoOperacion = Operacion.NINGUNO;
                break;
        }
    }
    
    public void btnEditar(){
        switch(tipoOperacion){
            case NINGUNO:
                btnEditar.setText("Guardar");
                btnEliminar.setDisable(true);
                btnReporte.setDisable(true);
                activarTF();   
                tipoOperacion = Operacion.EDITAR;
                break;
            case EDITAR:
                editarProducto();
                btnEditar.setText("Editar");
                tipoOperacion = Operacion.NINGUNO;
                break;               
        }
    }
    
    //Método para el boton de cancelar y ocultarlo de nuevo
    public void btnCancelar(){
        txtCodigoProducto.setText("");
        txtNombreProducto.setText("");
        txtCantidadProducto.setText("");
        txtBuscar.setText(null);
        
        btnGuardar.setDisable(true);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(false);
        btnNuevo.setDisable(false);
        
        btnCancelar.setVisible(false);
    
        tipoOperacion = Operacion.NINGUNO;
        btnEditar.setText("Editar");
        desactivarTF();
        tblProducto.getSelectionModel().clearSelection();
    }
    
    public void guardarProducto(){
        if(txtNombreProducto.getText().isEmpty()||txtCantidadProducto.getText().isEmpty()){
            error.setTitle("ERROR");
            error.setContentText("El registro ha fallado!!\nFaltan datos por ingresar");
            error.setHeaderText("Resultado:");
            error.show();
        }else{
            Producto registro = new Producto();
            registro.setNombreProducto(txtNombreProducto.getText());
            registro.setCantidad(Integer.parseInt(txtCantidadProducto.getText()));
                try {
                    PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Agregar_Producto(?,?)}");
                    procedimiento.setString(1, registro.getNombreProducto());
                    procedimiento.setInt(2, registro.getCantidad());
                    procedimiento.executeUpdate();
                    listaProducto.add(registro);
                    if(registro != null){
                        informacion.setTitle("Registro agregado");
                        informacion.setContentText("El registro se ha completado con exito");
                        informacion.setHeaderText("Resultado:");
                        informacion.show();
                        cargarDatos();
                        desactivarTF();
                    }
                    Image imagen = new Image(getClass().getResourceAsStream("/org/josegongora/img/nuevo.png"));//Creando un objeto de tipo Image
                    imgNuevo.setImage(imagen);//Cambiando la imagen del boton nuevo
                    btnNuevo.setText("Nuevo");
                    tipoOperacion = Operacion.NINGUNO;

                } catch (Exception e) {
                    e.printStackTrace();
                }
        }
    }
    
    public void eliminarProducto(){
        confirmacion.setTitle("Eliminar Registro");
        confirmacion.setHeaderText("¿Estas seguro de eliminar este registro?\nSe eliminarán todos los registros relacionados con el Producto");
        confirmacion.setContentText("Código: "+txtCodigoProducto.getText());
        Optional<ButtonType> opcion = confirmacion.showAndWait();
        if(opcion.get() == ButtonType.CANCEL){
                  informacion.setTitle("Información");
                  informacion.setContentText("Se ha cancelado el proceso.");
                  informacion.setHeaderText("Resultado:");
                  informacion.show();
                  cargarDatos();
        }else if(opcion.get() == ButtonType.OK){
            try {
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Eliminar_Producto(?)}");
                procedimiento.setInt(1, Integer.parseInt(txtCodigoProducto.getText()));
                int eli = procedimiento.executeUpdate();
                if(eli > 0){
                  informacion.setTitle("Registro Eliminado");
                  informacion.setContentText("El registro se ha eliminado con exito");
                  informacion.setHeaderText("Resultado:");
                  informacion.show();
                  cargarDatos();
                }else{
                  error.setTitle("Error");
                  error.setContentText("Error al intentar eliminar registro!!!");
                  error.setHeaderText("Resultado:");
                  error.show();
                  cargarDatos();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }                 
        }
    }
    
    public void editarProducto(){
        if(txtNombreProducto.getText().isEmpty()||txtCantidadProducto.getText().isEmpty()){
            error.setTitle("ERROR");
            error.setContentText("La modificación ha fallado!!\nFaltan datos por ingresar");
            error.setHeaderText("Resultado:");
            error.show();
        }else{
            try {
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Actualizar_Producto(?,?,?)}");
                procedimiento.setInt(1, Integer.parseInt(txtCodigoProducto.getText()));
                procedimiento.setString(2, txtNombreProducto.getText());
                procedimiento.setInt(3, Integer.parseInt(txtCantidadProducto.getText()));
                int resultado = procedimiento.executeUpdate();
                if(resultado > 0){
                  informacion.setTitle("Registro Modificado");
                  informacion.setContentText("El registro se ha modificado con exito");
                  informacion.setHeaderText("Resultado:");
                  informacion.show();
                  cargarDatos();
                }else{
                  error.setTitle("Error");
                  error.setContentText("Error al intentar modificar el registro!!!");
                  error.setHeaderText("Resultado:");
                  error.show();
                  cargarDatos();
                }     
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public Producto buscarProducto(int codigoProducto){
       Producto resultado = null;
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_Producto(?)}");
            procedimiento.setInt(1, codigoProducto);
            ResultSet registro = procedimiento.executeQuery();
            while(registro.next()){
                resultado = new Producto(registro.getInt("codigoProducto"),
                                         registro.getString("nombreProducto"),
                                         registro.getInt("cantidad"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }
    
    public void buscarProducto(){
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_Producto(?)}");
            procedimiento.setString(1, txtBuscar.getText());
            ResultSet resultado = procedimiento.executeQuery();
            if(resultado.next()){
                txtCodigoProducto.setText(resultado.getString("codigoProducto"));
                txtNombreProducto.setText(resultado.getString("nombreProducto"));
                txtCantidadProducto.setText(resultado.getString("cantidad"));
                desactivarBotones();
            }else{
                error.setTitle("ERROR");
                error.setHeaderText("Error:");
                error.setContentText("No existe un registro con codigo: "+txtBuscar.getText());
                error.show();
                txtBuscar.setText("");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public Producto buscarProductos(int codigoProducto){
        Producto resultado = null;
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_Plato(?)}");
            procedimiento.setInt(1, codigoProducto);
            ResultSet registro = procedimiento.executeQuery();
            while(registro.next()){
                resultado = new Producto(registro.getInt("codigoProducto"),
                                        registro.getString("nombreProducto"),
                                        registro.getInt("cantidad"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }
    
    //Método para limpiar Textfields y deshabilitar/habilitar botones 
    public void limpiarTF(){
        txtCodigoProducto.setText("");
        txtNombreProducto.setText("");
        txtCantidadProducto.setText("");
        txtBuscar.setText(null);
        
        btnGuardar.setDisable(true);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(false);
        btnNuevo.setDisable(false);
        
        btnCancelar.setVisible(false);
        
    }
    
    //Método para limpiar datos pero con otras instrucciones
    public void limpiarDos(){
        txtCodigoProducto.setText("");
        txtNombreProducto.setText("");
        txtCantidadProducto.setText("");
        txtBuscar.setText(null);
        
        btnGuardar.setDisable(false);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(true);
    }
    
    //Método para activar los TextField
    public void activarTF(){
        txtNombreProducto.setEditable(true);
        txtCantidadProducto.setEditable(true);
    }
    
    //Método para desactivar los TextField
    public void desactivarTF(){
        txtNombreProducto.setEditable(false);
        txtCantidadProducto.setEditable(false);
    }
    
    //Método para desactivar botones y hacer visible el boton cancelar
    public void desactivarBotones(){
        btnGuardar.setDisable(true);
        btnEditar.setDisable(false);
        btnEliminar.setDisable(false);
        btnReporte.setDisable(true);
        btnNuevo.setDisable(true);
        
        btnCancelar.setVisible(true);
    }
    
    //Método para comprobar la conexión a la base de datos
    public void estadoConexion(){
        try{
        if(Conexion.getInstance().getConexion() != null){
            informacion.setTitle("Conexión");
            informacion.setHeaderText("Resultado");
            informacion.setContentText("Conexion exitosa!!!");
            informacion.show();
        }else{
            error.setTitle("Conexión");
            error.setHeaderText("Resultado");
            error.setContentText("Error de conexión");
            error.show();
        }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void bloquearTamanioCol(){
        colCantidadProducto.setResizable(false);
        colCodigoProducto.setResizable(false);
        colNombreProducto.setResizable(false);
        colCantidadProducto.reorderableProperty().set(false);
        colCodigoProducto.reorderableProperty().set(false);
        colNombreProducto.reorderableProperty().set(false);
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cargarDatos();
        seleccionProducto();
        desactivarTF();
        bloquearTamanioCol();
    }

    public MainApp getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(MainApp escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
    
    public void menuPrincipal(){
        escenarioPrincipal.menuPrincipal();
    }
    
}
