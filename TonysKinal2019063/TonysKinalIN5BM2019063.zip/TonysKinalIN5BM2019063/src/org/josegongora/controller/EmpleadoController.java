package org.josegongora.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import org.josegongora.bd.Conexion;
import org.josegongora.bean.Empleado;
import org.josegongora.bean.TipoEmpleado;
import org.josegongora.system.MainApp;

public class EmpleadoController implements Initializable{
    private MainApp escenarioPrincipal;
    
    private enum Operacion{NUEVO,GUARDAR,ELIMINAR,EDITAR,CARGAR,NINGUNO}
    
    private Operacion tipoOperacion = Operacion.NINGUNO;
    
    ObservableList<TipoEmpleado> listaTipoEmpleado;
    ObservableList<Empleado> listaEmpleado;
     
    @FXML private JFXButton btnNuevo, btnGuardar, btnEliminar, btnEditar, btnReporte, btnCancelar;
    
    @FXML private JFXTextField txtCodigoEmpleado, txtNumero, txtNombres, txtApellidos, txtDireccion, txtTelefono, txtGradoCocinero;
    
    @FXML private TextField txtBuscar;
    
    @FXML private ImageView imgNuevo;
    
    @FXML private JFXComboBox cmbTipoEmpleado;
    
    @FXML private TableView tblEmpleado;
    
    @FXML private TableColumn colCodigoEmpleado, colNumero, colNombres, colApellidos, colDireccion, colTelefono, colGradoCocinero, colCodigoTipoEmpleado;
    
    Alert error = new Alert(AlertType.ERROR); //Creando objetos de tipo Alert para utilizar en toda la clase
    Alert informacion = new Alert(AlertType.INFORMATION);//Creando objetos de tipo Alert para utilizar en toda la clase
    Alert confirmacion  = new Alert(AlertType.CONFIRMATION);//Creando objetos de tipo Alert para utilizar en toda la clase
    
    public void cargarDatos(){
        tblEmpleado.setItems(getEmpleado());
        colCodigoEmpleado.setCellValueFactory(new PropertyValueFactory<Empleado, Integer>("codigoEmpleado"));
        colNumero.setCellValueFactory(new PropertyValueFactory<Empleado, Integer>("numeroEmpleado"));
        colApellidos.setCellValueFactory(new PropertyValueFactory<Empleado, String>("apellidosEmpleado"));
        colNombres.setCellValueFactory(new PropertyValueFactory<Empleado, String>("nombreEmpleado"));
        colDireccion.setCellValueFactory(new PropertyValueFactory<Empleado, String>("direccion"));
        colTelefono.setCellValueFactory(new PropertyValueFactory<Empleado, String>("telefonoContacto"));
        colGradoCocinero.setCellValueFactory(new PropertyValueFactory<Empleado, String>("gradoCocinero"));
        colCodigoTipoEmpleado.setCellValueFactory(new PropertyValueFactory<Empleado, Integer>("codigoTipoEmpleado"));
        cmbTipoEmpleado.setItems(getTipoEmpleado());
        limpiarTF();
        cmbTipoEmpleado.setEditable(true);
        cmbTipoEmpleado.getSelectionModel().clearSelection();
        tblEmpleado.getSelectionModel().clearSelection();
    }
    
    public void seleccionEmpleado(){
        tblEmpleado.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Empleado>(){
            @Override
            public void changed(ObservableValue<? extends Empleado> observable, Empleado valorAnterior, Empleado valorSeleccionado) {
                if(valorSeleccionado != null){
                    txtCodigoEmpleado.setText(String.valueOf(valorSeleccionado.getCodigoEmpleado()));
                    txtNumero.setText(String.valueOf(valorSeleccionado.getNumeroEmpleado()));
                    txtApellidos.setText(valorSeleccionado.getApellidosEmpleado());
                    txtNombres.setText(valorSeleccionado.getNombreEmpleado());
                    txtDireccion.setText(valorSeleccionado.getDireccion());
                    txtTelefono.setText(valorSeleccionado.getTelefonoContacto());
                    txtGradoCocinero.setText(valorSeleccionado.getGradoCocinero());
                    cmbTipoEmpleado.setValue(buscarTipoEmpleado(valorSeleccionado.getCodigoTipoEmpleado()));
                    desactivarBotones();
                    desactivarTF();
                }
            }
        
            }
        );
    }
    
    //Método para ejecutar el procedimiento almacenado
    public ObservableList<TipoEmpleado> getTipoEmpleado(){
        ArrayList<TipoEmpleado> lista = new ArrayList<TipoEmpleado>();
        try {
            PreparedStatement sp = Conexion.getInstance().getConexion().prepareCall("{call sp_Listar_TipoEmpleado()}");
            ResultSet resultado = sp.executeQuery();
            while(resultado.next()){
                lista.add(new TipoEmpleado(resultado.getInt("codigoTipoEmpleado"),
                resultado.getString("descripcion")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaTipoEmpleado = FXCollections.observableArrayList(lista);
    }
    
    public TipoEmpleado buscarTipoEmpleado(int codigoTipoEmpleado){
        TipoEmpleado resultado = null;
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_TipoEmpleado(?)}");
            procedimiento.setInt(1, codigoTipoEmpleado);
            ResultSet registro = procedimiento.executeQuery();
            while(registro.next()){
                resultado = new TipoEmpleado(registro.getInt("codigoTipoEmpleado"),
                                             registro.getString("descripcion"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }
    
    public ObservableList<Empleado> getEmpleado(){
        ArrayList<Empleado> lista = new ArrayList<Empleado>();
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Listar_Empleado()}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new Empleado (resultado.getInt("codigoEmpleado"),
                resultado.getInt("numeroEmpleado"),
                resultado.getString("apellidosEmpleado"),
                resultado.getString("nombreEmpleado"),
                resultado.getString("direccion"),
                resultado.getString("telefonoContacto"),
                resultado.getString("gradoCocinero"),
                resultado.getInt("codigoTipoEmpleado")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaEmpleado = FXCollections.observableArrayList(lista);
    }
    
    public void btnNuevo(){
        switch(tipoOperacion){
            case NINGUNO:
                Image img = new Image(getClass().getResourceAsStream("/org/josegongora/img/cancelar.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(img);//Cambiando la imagen del boton nuevo
                btnGuardar.setDisable(false);
                btnNuevo.setText("Cancelar");
                cmbTipoEmpleado.setEditable(false);
                activarTF();
                limpiarDos();
                tipoOperacion = Operacion.GUARDAR;
                break;
            case GUARDAR:
                Image imagen = new Image(getClass().getResourceAsStream("/org/josegongora/img/nuevo.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(imagen);//Cambiando la imagen del boton nuevo
                btnGuardar.setDisable(true);
                btnNuevo.setText("Nuevo");
                limpiarTF();
                desactivarTF();
                cargarDatos();
                tipoOperacion = Operacion.NINGUNO;
                break;
        }
    }
    
     public void btnEditar(){
        switch(tipoOperacion){
            case NINGUNO:
                txtCodigoEmpleado.setEditable(true);
                txtNumero.setEditable(true);
                txtApellidos.setEditable(true);
                txtNombres.setEditable(true);
                txtDireccion.setEditable(true);
                txtTelefono.setEditable(true);
                txtGradoCocinero.setEditable(true);
                cmbTipoEmpleado.setDisable(true);
                btnEliminar.setDisable(true);
                btnReporte.setDisable(true);
                btnEditar.setText("Guardar");
                tipoOperacion = Operacion.EDITAR;
                break;
            case EDITAR:
                editarEmpleado();
                cmbTipoEmpleado.getSelectionModel().clearSelection();
                btnEditar.setText("Editar");
                tipoOperacion = Operacion.NINGUNO;
                break;
        }
    }
    
    public void btnCancelar(){
        txtCodigoEmpleado.setText("");
        txtNumero.setText("");
        txtApellidos.setText("");
        txtNombres.setText("");
        txtDireccion.setText("");
        txtTelefono.setText("");
        txtGradoCocinero.setText("");
        cmbTipoEmpleado.getSelectionModel().select(null);
        txtBuscar.setText(null);
        
        btnGuardar.setDisable(true);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(false);
        btnNuevo.setDisable(false);
        
        btnCancelar.setVisible(false);
    
        tipoOperacion = Operacion.NINGUNO;
        btnEditar.setText("Editar");
        
        desactivarTF();
        
        tblEmpleado.getSelectionModel().clearSelection();
    }
    
    public void agregarEmpleado(){
        if(txtNumero.getText().isEmpty()||txtNombres.getText().isEmpty()||txtDireccion.getText().isEmpty()||txtTelefono.getText().isEmpty()||cmbTipoEmpleado.getValue() == null){
            error.setTitle("ERROR");
            error.setContentText("El registro ha fallado!!\nFaltan datos por ingresar");
            error.setHeaderText("Resultado:");
            error.show();
        }else{
            Empleado registro = new Empleado();
            registro.setNumeroEmpleado(Integer.parseInt(txtNumero.getText()));
            registro.setApellidosEmpleado(txtApellidos.getText());
            registro.setNombreEmpleado(txtNombres.getText());
            registro.setDireccion(txtDireccion.getText());
            registro.setTelefonoContacto(txtTelefono.getText());
            registro.setGradoCocinero(txtGradoCocinero.getText());
            registro.setCodigoTipoEmpleado(((TipoEmpleado)cmbTipoEmpleado.getSelectionModel().getSelectedItem()).getCodigoTipoEmpleado());
            
            try{
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Agregar_Empleado(?,?,?,?,?,?,?)}");
                procedimiento.setInt(1, registro.getNumeroEmpleado());
                procedimiento.setString(2, registro.getApellidosEmpleado());
                procedimiento.setString(3, registro.getNombreEmpleado());
                procedimiento.setString(4, registro.getDireccion());
                procedimiento.setString(5, registro.getTelefonoContacto());
                procedimiento.setString(6, registro.getGradoCocinero());
                procedimiento.setInt(7, registro.getCodigoTipoEmpleado());
                procedimiento.execute();
                listaEmpleado.add(registro);
                if(registro != null){
                        informacion.setTitle("Registro agregado");
                        informacion.setContentText("El registro se ha completado con exito");
                        informacion.setHeaderText("Resultado:");
                        informacion.show();
                        cargarDatos();
                        desactivarTF();
                }
                Image imagen = new Image(getClass().getResourceAsStream("/org/josegongora/img/nuevo.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(imagen);//Cambiando la imagen del boton nuevo
                btnNuevo.setText("Nuevo");
                tipoOperacion = Operacion.NINGUNO;
            }catch(Exception e){
                e.printStackTrace();
            }
        }
    }
    
    public void editarEmpleado(){
        if(txtNumero.getText().isEmpty()||txtNombres.getText().isEmpty()||txtDireccion.getText().isEmpty()||txtTelefono.getText().isEmpty()||cmbTipoEmpleado.getValue() == null){
            error.setTitle("ERROR");
            error.setContentText("La modificación ha fallado!!\nFaltan datos por ingresar");
            error.setHeaderText("Resultado:");
            error.show();
        }else{
            try {
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Actualizar_Empleado(?,?,?,?,?,?,?)}");
                procedimiento.setInt(1, Integer.parseInt(txtCodigoEmpleado.getText()));
                procedimiento.setString(2, txtNumero.getText());
                procedimiento.setString(3, txtApellidos.getText());
                procedimiento.setString(4, txtNombres.getText());
                procedimiento.setString(5, txtDireccion.getText());
                procedimiento.setString(6, txtTelefono.getText());
                procedimiento.setString(7, txtGradoCocinero.getText());
                int res = procedimiento.executeUpdate();
                    if(res > 0){
                      informacion.setTitle("Registro Modificado");
                      informacion.setContentText("El registro se ha modificado con exito");
                      informacion.setHeaderText("Resultado:");
                      informacion.show();
                      cargarDatos();
                    }else{
                      error.setTitle("Error");
                      error.setContentText("Error al intentar modificar el registro!!!");
                      error.setHeaderText("Resultado:");
                      error.show();
                      cargarDatos();
                    }     
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public void eliminarEmpleado(){
        confirmacion.setTitle("Eliminar Registro");
        confirmacion.setHeaderText("¿Estas seguro de eliminar este registro?\nSe eliminarán todos los registros relacionados con el Empleado");
        confirmacion.setContentText("Código: "+txtCodigoEmpleado.getText());
        Optional<ButtonType> opcion = confirmacion.showAndWait();
        if(opcion.get() == ButtonType.CANCEL){
           informacion.setTitle("Información");
           informacion.setContentText("Se ha cancelado el proceso.");
           informacion.setHeaderText("Resultado:");
           informacion.show();
           cargarDatos();
        }else if(opcion.get() == ButtonType.OK){

            try {
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Eliminar_Empleado(?)}");
                procedimiento.setInt(1, Integer.parseInt(txtCodigoEmpleado.getText()));
                int eli = procedimiento.executeUpdate();
                if(eli > 0){
                  informacion.setTitle("Registro Eliminado");
                  informacion.setContentText("El registro se ha eliminado con exito");
                  informacion.setHeaderText("Resultado:");
                  informacion.show();
                  cargarDatos();
                }else{
                  error.setTitle("Error");
                  error.setContentText("Error al intentar eliminar registro!!!");
                  error.setHeaderText("Resultado:");
                  error.show();
                  cargarDatos();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }                 
        }
    }
    
    public void buscarDatos(){
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_Empleado(?)}");
            procedimiento.setString(1, txtBuscar.getText());
            ResultSet resultado = procedimiento.executeQuery();
            if(resultado.next()){
                txtCodigoEmpleado.setText(resultado.getString("codigoEmpleado"));
                txtNumero.setText(resultado.getString("numeroEmpleado"));
                txtApellidos.setText(resultado.getString("apellidosEmpleado"));
                txtNombres.setText(resultado.getString("nombreEmpleado"));
                txtDireccion.setText(resultado.getString("direccion"));
                txtTelefono.setText(resultado.getString("telefonoContacto"));
                txtGradoCocinero.setText(resultado.getString("gradoCocinero"));
                cmbTipoEmpleado.setValue(buscarTipoEmpleado(resultado.getInt("codigoTipoEmpleado")));
                desactivarBotones();
            }else{
                error.setTitle("ERROR");
                error.setHeaderText("Error:");
                error.setContentText("No existe un registro con codigo: "+txtBuscar.getText());
                error.show();
                txtBuscar.setText("");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    //Método para buscar empleado desde otra clase
    public Empleado buscarEmpleado(int codigoEmpleado){
        Empleado resultado = null;
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_Empresa(?)}");
            procedimiento.setInt(1, codigoEmpleado);
            ResultSet registro = procedimiento.executeQuery();
            while(registro.next()){
                resultado = new Empleado (registro.getInt("codigoEmpleado"),
                                            registro.getInt("numeroEmpleado"),
                                            registro.getString("apellidosEmpleado"),
                                            registro.getString("nombreEmpleado"),
                                            registro.getString("direccion"),
                                            registro.getString("telefonoContacto"),
                                            registro.getString("gradoCocinero"),
                                            registro.getInt("codigoTipoEmpleado"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }
    
    //Método para limpiar Textfields y deshabilitar/habilitar botones 
    public void limpiarTF(){
        txtCodigoEmpleado.setText("");
        txtNumero.setText("");
        txtApellidos.setText("");
        txtNombres.setText("");
        txtDireccion.setText("");
        txtTelefono.setText("");
        txtGradoCocinero.setText("");
        cmbTipoEmpleado.getSelectionModel().clearSelection();
        txtBuscar.setText(null);
        
        btnGuardar.setDisable(true);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(false);
        btnNuevo.setDisable(false);
        
        btnCancelar.setVisible(false);
        
    }
    
    //Método para limpiar datos pero con otras instrucciones
    public void limpiarDos(){
        txtCodigoEmpleado.setText("");
        txtNumero.setText("");
        txtApellidos.setText("");
        txtNombres.setText("");
        txtDireccion.setText("");
        txtTelefono.setText("");
        txtGradoCocinero.setText("");
        cmbTipoEmpleado.getSelectionModel().clearSelection();
        txtBuscar.setText(null);
        
        btnGuardar.setDisable(false);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(true);
    }
    
    //Método para activar los TextField
    public void activarTF(){
        txtCodigoEmpleado.setEditable(true);
        txtNumero.setEditable(true);
        txtApellidos.setEditable(true);
        txtNombres.setEditable(true);
        txtDireccion.setEditable(true);
        txtTelefono.setEditable(true);
        txtGradoCocinero.setEditable(true);
        cmbTipoEmpleado.setEditable(false);
        cmbTipoEmpleado.setDisable(false);
    }
    
    //Método para desactivar los TextField
    public void desactivarTF(){
        txtCodigoEmpleado.setEditable(false);
        txtNumero.setEditable(false);
        txtApellidos.setEditable(false);
        txtNombres.setEditable(false);
        txtDireccion.setEditable(false);
        txtTelefono.setEditable(false);
        txtGradoCocinero.setEditable(false);
        cmbTipoEmpleado.setDisable(true);
    }
    
    //Método para desactivar botones y hacer visible el boton cancelar
    public void desactivarBotones(){
        btnGuardar.setDisable(true);
        btnEditar.setDisable(false);
        btnEliminar.setDisable(false);
        btnReporte.setDisable(true);
        btnNuevo.setDisable(true);
        
        btnCancelar.setVisible(true);
    }
    
    //Método para comprobar la conexión a la base de datos
    public void estadoConexion(){
        try{
        if(Conexion.getInstance().getConexion() != null){
            informacion.setTitle("Conexión");
            informacion.setHeaderText("Resultado");
            informacion.setContentText("Conexion exitosa!!!");
            informacion.show();
        }else{
            error.setTitle("Conexión");
            error.setHeaderText("Resultado");
            error.setContentText("Error de conexión");
            error.show();
        }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void bloquearTamanioCol(){
        colCodigoEmpleado.setResizable(false);
        colApellidos.setResizable(false);
        colNombres.setResizable(false);
        colDireccion.setResizable(false);
        colGradoCocinero.setResizable(false);
        colNumero.setResizable(false);
        colTelefono.setResizable(false);
        colCodigoTipoEmpleado.setResizable(false);
        colCodigoEmpleado.reorderableProperty().set(false);
        colApellidos.reorderableProperty().set(false);
        colNombres.reorderableProperty().set(false);
        colDireccion.reorderableProperty().set(false);
        colGradoCocinero.reorderableProperty().set(false);
        colNumero.reorderableProperty().set(false);
        colTelefono.reorderableProperty().set(false);
        colCodigoTipoEmpleado.reorderableProperty().set(false);
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cargarDatos();
        desactivarTF();
        seleccionEmpleado();
        bloquearTamanioCol();
    }

    public MainApp getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(MainApp escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
    
    public void menuPrincipal(){
        escenarioPrincipal.menuPrincipal();
    }
    
}
