package org.josegongora.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import eu.schudt.javafx.controls.calendar.DatePicker;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import org.josegongora.bd.Conexion;
import org.josegongora.bean.Empresa;
import org.josegongora.bean.Presupuesto;
import org.josegongora.report.GenerarReporte;
import org.josegongora.system.MainApp;


public class PresupuestoController implements Initializable {
    private MainApp escenarioPrincipal;
    private enum Operacion{NUEVO,GUARDAR,ELIMINAR,EDITAR,CARGAR,NINGUNO}
    private Operacion tipoOperacion = Operacion.NINGUNO;
    
    private ObservableList<Empresa> listaEmpresa;
    private ObservableList<Presupuesto> listaPresupuesto;
    
    private DatePicker fechaSolicitud;
    
    @FXML ImageView imgCalendario, imgNuevo;
    
    @FXML private GridPane grpFechaSolicitud;
    
    @FXML private JFXButton btnNuevo, btnGuardar, btnEliminar, btnEditar, btnReporte, btnCancelar, btnCalendario;
    
    @FXML private JFXTextField txtCodigoPresupuesto, txtCantidadPresupuesto;
    
    @FXML private TextField txtBuscar;
    
    @FXML private JFXComboBox cmbEmpresa;
    
    @FXML private TableView tblPresupuesto;
    
    @FXML private TableColumn colCodigoPresupuesto, colFechaSolicitud, colCantidadPresupuesto, colCodigoEmpresa;
    
    Alert error = new Alert(AlertType.ERROR); //Creando objetos de tipo Alert para utilizar en toda la clase
    Alert informacion = new Alert(AlertType.INFORMATION);//Creando objetos de tipo Alert para utilizar en toda la clase
    Alert confirmacion  = new Alert(AlertType.CONFIRMATION);//Creando objetos de tipo Alert para utilizar en toda la clase

    
    
    public void cargarDatos(){
        tblPresupuesto.setItems(getPresupuesto());
        colCodigoPresupuesto.setCellValueFactory(new PropertyValueFactory<Presupuesto, Integer>("codigoPresupuesto"));
        colFechaSolicitud.setCellValueFactory(new PropertyValueFactory<Presupuesto, Date>("fecha_Solicitud"));
        colCantidadPresupuesto.setCellValueFactory(new PropertyValueFactory<Presupuesto, Double>("cantidadPresupuesto"));
        colCodigoEmpresa.setCellValueFactory(new PropertyValueFactory<Presupuesto, Integer>("codigoEmpresa"));
        cmbEmpresa.setItems(getEmpresa());
        cmbEmpresa.setEditable(true);
        limpiarTF();
        cmbEmpresa.getSelectionModel().select(null);
        tblPresupuesto.getSelectionModel().clearSelection();
    }
     
    public void seleccionPresupuesto(){
        tblPresupuesto.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Presupuesto>(){
            @Override
            public void changed(ObservableValue<? extends Presupuesto> observable, Presupuesto valorAnterior, Presupuesto valorSeleccionado) {
                    if(valorSeleccionado != null){
                        txtCodigoPresupuesto.setText(String.valueOf(valorSeleccionado.getCodigoPresupuesto()));
                        fechaSolicitud.selectedDateProperty().set(valorSeleccionado.getFecha_Solicitud());
                        txtCantidadPresupuesto.setText(String.valueOf(valorSeleccionado.getCantidadPresupuesto()));
                        cmbEmpresa.setValue(buscarEmpresa(valorSeleccionado.getCodigoEmpresa()));
                        desactivarBotones();
                        desactivarTF();
                    }
            }
            
        }
        );
    }
    
    public ObservableList<Presupuesto> getPresupuesto(){
        ArrayList<Presupuesto> lista = new ArrayList<Presupuesto>();
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Listar_Presupuesto()}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new Presupuesto ( resultado.getInt("codigoPresupuesto"),
                        resultado.getDate("fecha_Solicitud"),
                        resultado.getDouble("cantidadPresupuesto"),
                        resultado.getInt("codigoEmpresa")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaPresupuesto = FXCollections.observableArrayList(lista);
    }
    
    public ObservableList<Empresa> getEmpresa(){
        ArrayList<Empresa> lista = new ArrayList<Empresa>();
        try{
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Listar_Empresa()}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new Empresa(resultado.getInt("codigoEmpresa"), 
                resultado.getString("nombreEmpresa"),
                resultado.getString("direccion"),
                resultado.getString("telefono")));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return listaEmpresa = FXCollections.observableArrayList(lista);
    }
    
    //Método para buscar empresa desde otra clase
    public Empresa buscarEmpresa(int codigoEmpresa){
        Empresa resultado = null;
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_Empresa(?)}");
            procedimiento.setInt(1, codigoEmpresa);
            ResultSet registro = procedimiento.executeQuery();
            while(registro.next()){
                resultado = new Empresa(registro.getInt("codigoEmpresa"),
                                        registro.getString("nombreEmpresa"),
                                        registro.getString("direccion"),
                                        registro.getString("telefono"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }
    
    public void buscarDatos(){
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_Presupuesto(?)}");
            procedimiento.setString(1, txtBuscar.getText());
            ResultSet resultado = procedimiento.executeQuery();
            if(resultado.next()){
                txtCodigoPresupuesto.setText(resultado.getString("codigoPresupuesto"));
                fechaSolicitud.selectedDateProperty().set(resultado.getDate("fecha_Solicitud"));
                txtCantidadPresupuesto.setText(String.valueOf(resultado.getDouble("cantidadPresupuesto")));
                cmbEmpresa.setValue(buscarEmpresa(resultado.getInt("codigoEmpresa")));
                desactivarBotones();
            }else{
                error.setTitle("ERROR");
                error.setHeaderText("Error:");
                error.setContentText("No existe un registro con codigo: "+txtBuscar.getText());
                error.show();
                txtBuscar.setText("");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void btnNuevo(){
        switch(tipoOperacion){
            case NINGUNO:
                Image img = new Image(getClass().getResourceAsStream("/org/josegongora/img/cancelar.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(img);//Cambiando la imagen del boton nuevo
                btnGuardar.setDisable(false);
                btnNuevo.setText("Cancelar");
                activarTF();
                limpiarDos();
                tipoOperacion = Operacion.GUARDAR;
                break;
            case GUARDAR:
                Image imagen = new Image(getClass().getResourceAsStream("/org/josegongora/img/nuevo.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(imagen);//Cambiando la imagen del boton nuevo
                btnGuardar.setDisable(true);
                btnNuevo.setText("Nuevo");
                limpiarTF();
                fechaSolicitud.selectedDateProperty().set(null);
                desactivarTF();
                cargarDatos();
                tipoOperacion = Operacion.NINGUNO;
                break;
        }
    }
    
    public void btnEditar(){
        switch(tipoOperacion){
            case NINGUNO:
                txtCantidadPresupuesto.setEditable(true);
                grpFechaSolicitud.setDisable(false);
                cmbEmpresa.setDisable(true);
                btnEliminar.setDisable(true);
                btnReporte.setDisable(true);
                btnEditar.setText("Guardar");
                tipoOperacion = Operacion.EDITAR;
                break;
            case EDITAR:
                editarDatos();
                cmbEmpresa.getSelectionModel().clearSelection();
                btnEditar.setText("Editar");
                tipoOperacion = Operacion.NINGUNO;
                break;
        }
    }
        
    public void btnCancelar(){
        txtCodigoPresupuesto.setText("");
        txtCantidadPresupuesto.setText("");
        fechaSolicitud.selectedDateProperty().set(null);
        cmbEmpresa.getSelectionModel().select(null);

        txtBuscar.setText(null);
        
        btnGuardar.setDisable(true);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(true);
        btnNuevo.setDisable(false);
        
        btnCancelar.setVisible(false);
    
        tipoOperacion = Operacion.NINGUNO;
        btnEditar.setText("Editar");
        
        desactivarTF();
        
        tblPresupuesto.getSelectionModel().clearSelection();
    }

    public void guardarDatos(){
        if(fechaSolicitud.getSelectedDate() == null || txtCantidadPresupuesto.getText().isEmpty()|| cmbEmpresa.getValue() == null){
            error.setTitle("Error");
            error.setHeaderText("Resultado:");
            error.setContentText("El registro ha fallado!!\nFaltan datos por ingresar");
            error.show();
        }else{
        Presupuesto registro = new Presupuesto();
        registro.setFecha_Solicitud(fechaSolicitud.getSelectedDate());
        registro.setCantidadPresupuesto(Double.parseDouble(txtCantidadPresupuesto.getText()));
        registro.setCodigoEmpresa(((Empresa)cmbEmpresa.getSelectionModel().getSelectedItem()).getCodigoEmpresa());
            try {
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Agregar_Presupuesto(?,?,?)}");
                procedimiento.setDate(1, new java.sql.Date(registro.getFecha_Solicitud().getTime()));
                procedimiento.setDouble(2, registro.getCantidadPresupuesto());
                procedimiento.setInt(3, registro.getCodigoEmpresa());
                procedimiento.execute();
                listaPresupuesto.add(registro);
                if(registro != null){
                    informacion.setTitle("Registro agregado");
                    informacion.setContentText("El registro se ha completado con exito");
                    informacion.setHeaderText("Resultado:");
                    informacion.show();
                    cargarDatos();
                    desactivarTF();
                }
                Image imagen = new Image(getClass().getResourceAsStream("/org/josegongora/img/nuevo.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(imagen);//Cambiando la imagen del boton nuevo
                btnNuevo.setText("Nuevo");
                tipoOperacion = Operacion.NINGUNO;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public void editarDatos(){
        if(fechaSolicitud.getSelectedDate() == null|txtCantidadPresupuesto.getText().isEmpty()|cmbEmpresa.getValue() == null){
          error.setTitle("ERROR");
          error.setContentText("La modificación ha fallado!!\nFaltan datos por ingresar");
          error.setHeaderText("Resultado:");
          error.show();
        }else{
            try {
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Actualizar_Presupuesto(?,?,?)}");
                procedimiento.setInt(1, Integer.parseInt(txtCodigoPresupuesto.getText()));
                procedimiento.setDate(2, new java.sql.Date(fechaSolicitud.getSelectedDate().getTime()));
                procedimiento.setDouble(3, Double.parseDouble(txtCantidadPresupuesto.getText()));
                int res = procedimiento.executeUpdate();
                if(res > 0){
                  informacion.setTitle("Registro Modificado");
                  informacion.setContentText("El registro se ha modificado con exito");
                  informacion.setHeaderText("Resultado:");
                  informacion.show();
                  grpFechaSolicitud.setDisable(true);
                  cargarDatos();
                }else{
                  error.setTitle("Error");
                  error.setContentText("Error al intentar modificar el registro!!!");
                  error.setHeaderText("Resultado:");
                  error.show();
                  cargarDatos();
                }     
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public void eliminarDatos(){
        confirmacion.setTitle("Eliminar Registro");
        confirmacion.setHeaderText("¿Estas seguro de eliminar este registro?");
        confirmacion.setContentText("Código: "+txtCodigoPresupuesto.getText());
        Optional<ButtonType> opcion = confirmacion.showAndWait();
        if(opcion.get() == ButtonType.CANCEL){
           informacion.setTitle("Información");
           informacion.setContentText("Se ha cancelado el proceso.");
           informacion.setHeaderText("Resultado:");
           informacion.show();
           cargarDatos();
        }else if(opcion.get() == ButtonType.OK){
            try {
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Eliminar_Presupuesto(?)}");
                procedimiento.setInt(1, Integer.parseInt(txtCodigoPresupuesto.getText()));
                int eli = procedimiento.executeUpdate();
                if(eli > 0){
                  informacion.setTitle("Registro Eliminado");
                  informacion.setContentText("El registro se ha eliminado con exito");
                  informacion.setHeaderText("Resultado:");
                  informacion.show();
                  fechaSolicitud.selectedDateProperty().set(null);
                  cargarDatos();
                }else{
                  error.setTitle("Error");
                  error.setContentText("Error al intentar eliminar registro!!!");
                  error.setHeaderText("Resultado:");
                  error.show();
                  cargarDatos();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }                 
        }
    }
    
    public void imprimirReporte(){
        Map parametros = new HashMap();
        int codEmpresa = Integer.valueOf(((Empresa)cmbEmpresa.getSelectionModel().getSelectedItem()).getCodigoEmpresa());
        parametros.put("codEmpresa",codEmpresa);
        GenerarReporte.mostrarReporte("ReportePresupuestos.jasper", "Reporte de Presupuesto", parametros);
        cargarDatos();
    }
    
    //Método para limpiar Textfields y deshabilitar/habilitar botones 
    public void limpiarTF(){
        txtCodigoPresupuesto.setText("");
        txtCantidadPresupuesto.setText("");
        //fechaSolicitud.selectedDateProperty().set(null);
        cmbEmpresa.getSelectionModel().clearSelection();
        txtBuscar.setText(null);
        
        btnGuardar.setDisable(true);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(true);
        btnNuevo.setDisable(false);
        
        btnCancelar.setVisible(false);
        
    }
    
    //Método para limpiar datos pero con otras instrucciones
    public void limpiarDos(){
        txtCodigoPresupuesto.setText("");
        txtCantidadPresupuesto.setText("");
        //fechaSolicitud.selectedDateProperty().set(null);
        cmbEmpresa.getSelectionModel().clearSelection();
        txtBuscar.setText(null);
        
        btnGuardar.setDisable(false);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(true);
    }
    
    //Método para activar los TextField
    public void activarTF(){
        txtCantidadPresupuesto.setEditable(true);
        grpFechaSolicitud.setDisable(false);
        cmbEmpresa.setDisable(false);
        cmbEmpresa.setEditable(false);
    }
    
    //Método para desactivar los TextField
    public void desactivarTF(){
        txtCantidadPresupuesto.setEditable(false);
        grpFechaSolicitud.setDisable(true);
        cmbEmpresa.setDisable(true);
    }
    
    //Método para desactivar botones y hacer visible el boton cancelar
    public void desactivarBotones(){
        btnGuardar.setDisable(true);
        btnEditar.setDisable(false);
        btnEliminar.setDisable(false);
        btnReporte.setDisable(false);
        btnNuevo.setDisable(true);
        
        btnCancelar.setVisible(true);
    }
    
    //Método para comprobar la conexión a la base de datos
    public void estadoConexion(){
        try{
        if(Conexion.getInstance().getConexion() != null){
            informacion.setTitle("Conexión");
            informacion.setHeaderText("Resultado");
            informacion.setContentText("Conexion exitosa!!!");
            informacion.show();
        }else{
            error.setTitle("Conexión");
            error.setHeaderText("Resultado");
            error.setContentText("Error de conexión");
            error.show();
        }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void bloquearTamanioCol(){
        colCodigoPresupuesto.setResizable(false);
        colFechaSolicitud.setResizable(false);
        colCantidadPresupuesto.setResizable(false);
        colCodigoEmpresa.setResizable(false);
        colCodigoPresupuesto.reorderableProperty().set(false);
        colFechaSolicitud.reorderableProperty().set(false);
        colCantidadPresupuesto.reorderableProperty().set(false);
        colCodigoEmpresa.reorderableProperty().set(false);
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cargarDatos();
        desactivarTF();
        seleccionPresupuesto();
        bloquearTamanioCol();
        fechaSolicitud = new DatePicker(Locale.ENGLISH);
        fechaSolicitud.setDateFormat(new SimpleDateFormat("yyyy-MM-dd"));
        //fechaSolicitud.setBlendMode(BlendMode.COLOR_BURN);
        fechaSolicitud.setId("datePicker");
        fechaSolicitud.setPromptText("Fecha Solicitud (yyyy-MM-dd)");
        fechaSolicitud.getCalendarView().todayButtonTextProperty().set("Hoy");
        fechaSolicitud.getCalendarView().setShowWeeks(false);
        fechaSolicitud.getStylesheets().add("org/josegongora/resources/DatePicker.css");
        grpFechaSolicitud.add(fechaSolicitud, 0, 0);
    }


    
    public MainApp getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(MainApp escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
    
    public void menuPrincipal(){
        escenarioPrincipal.menuPrincipal();
    }
    
}

