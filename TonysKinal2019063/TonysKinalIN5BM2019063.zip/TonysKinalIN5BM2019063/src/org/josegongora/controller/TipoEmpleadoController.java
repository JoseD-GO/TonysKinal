package org.josegongora.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import org.josegongora.bd.Conexion;
import org.josegongora.bean.TipoEmpleado;
import org.josegongora.system.MainApp;


public class TipoEmpleadoController implements Initializable{
    private MainApp escenarioPrincipal;
    
    private enum Operacion{NUEVO,GUARDAR,ELIMINAR,EDITAR,CARGAR,NINGUNO}
    
    private Operacion tipoOperacion = Operacion.NINGUNO;
    
    ObservableList<TipoEmpleado> listaTipoEmpleado;
    
    @FXML private TableColumn colCodigoTipoEmpleado, colDescripcionTipoEmpleado;
    
    @FXML private TableView tblTipoEmpleado;
    
    @FXML private JFXTextField txtCodigoTipoEmpleado, txtDescripcionTipoEmpleado;
    
    @FXML private JFXButton btnNuevo, btnGuardar, btnEliminar, btnBuscar, btnReporte, btnCancelar,btnEditar;
    
    @FXML private TextField txtBuscar;
    
    @FXML private ImageView imgNuevo;
    
    Alert informacion = new Alert(AlertType.INFORMATION); //Creando objetos de tipo Alert para utilizar en toda la clase
    Alert error = new Alert(AlertType.ERROR); //Creando objetos de tipo Alert para utilizar en toda la clase
    Alert confirmacion = new Alert(AlertType.CONFIRMATION); //Creando objetos de tipo Alert para utilizar en toda la clase
    
    //Método para ejecutar el procedimiento almacenado
    public ObservableList<TipoEmpleado> getTipoEmpleado(){
        ArrayList<TipoEmpleado> lista = new ArrayList<TipoEmpleado>();
        try {
            PreparedStatement sp = Conexion.getInstance().getConexion().prepareCall("{call sp_Listar_TipoEmpleado()}");
            ResultSet resultado = sp.executeQuery();
            while(resultado.next()){
                lista.add(new TipoEmpleado(resultado.getInt("codigoTipoEmpleado"),
                resultado.getString("descripcion")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaTipoEmpleado = FXCollections.observableArrayList(lista);
    }
    
    //Metodo para mostrar datos en la tabla
    public void cargarDatos(){
        tblTipoEmpleado.setItems(getTipoEmpleado());
        colCodigoTipoEmpleado.setCellValueFactory(new PropertyValueFactory<TipoEmpleado, Integer>("codigoTipoEmpleado"));
        colDescripcionTipoEmpleado.setCellValueFactory(new PropertyValueFactory<TipoEmpleado, String>("descripcion"));
        limpiarTF();
        tblTipoEmpleado.getSelectionModel().clearSelection();
    }
    
    //Método para seleccionar una empresa de la tabla
    public void seleccionTipoEmpleado(){
        tblTipoEmpleado.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<TipoEmpleado>(){
            @Override
            public void changed(ObservableValue<? extends TipoEmpleado> observable, TipoEmpleado valorAnterior, TipoEmpleado valorSeleccionado) {
                if(valorSeleccionado != null){
                    txtCodigoTipoEmpleado.setText(String.valueOf(valorSeleccionado.getCodigoTipoEmpleado()));
                    txtDescripcionTipoEmpleado.setText(valorSeleccionado.getDescripcion());
                    desactivarBotones();
                    desactivarTF();
                }
            }
            
        }
        );
    }
    
    //Método para el boton nuevo con ENUMERACION
    public void btnNuevo(){
        switch(tipoOperacion){
            case NINGUNO:
                Image img = new Image(getClass().getResourceAsStream("/org/josegongora/img/cancelar.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(img);//Cambiando la imagen del boton nuevo
                btnGuardar.setDisable(true);
                btnNuevo.setText("Cancelar");
                activarTF();
                limpiarDos();
                tipoOperacion = Operacion.GUARDAR;
                break;
            case GUARDAR:
                Image imagen = new Image(getClass().getResourceAsStream("/org/josegongora/img/nuevo.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(imagen);//Cambiando la imagen del boton nuevo
                btnGuardar.setDisable(false);
                btnNuevo.setText("Nuevo");
                limpiarTF();
                desactivarTF();
                tipoOperacion = Operacion.NINGUNO;
                break;
        }
    }
    
    public void btnEditar(){
        switch(tipoOperacion){
            case NINGUNO:
                activarTF();
                btnEditar.setText("Guardar");
                btnReporte.setDisable(true);
                btnEliminar.setDisable(true);
                tipoOperacion = Operacion.EDITAR;
                break;
            case EDITAR:
                modificarTipoEmpleado();
                btnEditar.setText("Editar");
                tipoOperacion = Operacion.NINGUNO;
                break;
        }
    }
    
    //Método para guardar datos en la tabla
    public void guardarTipoEmpleado(){
        TipoEmpleado tE = new TipoEmpleado();
        tE.setDescripcion(txtDescripcionTipoEmpleado.getText());
        if(tE.getDescripcion().equals("")){
            error.setTitle("Error");
            error.setHeaderText("Resultado");
            error.setContentText("El registro ha fallado!!\nFaltan datos por ingresar"); 
            error.show();
        }else{
            try {
                PreparedStatement pS = Conexion.getInstance().getConexion().prepareCall("{call sp_Agregar_TipoEmpleado(?)}");
                pS.setString(1, tE.getDescripcion());
                pS.executeUpdate();
                listaTipoEmpleado.add(tE);
                if(tE != null){
                    informacion.setTitle("Registro Agregado");
                    informacion.setHeaderText("Resultado:");
                    informacion.setContentText("El registro se ha completado con exito!!");
                    informacion.show();
                    cargarDatos();
                }
                
                Image imagen = new Image(getClass().getResourceAsStream("/org/josegongora/img/nuevo.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(imagen);//Cambiando la imagen del boton nuevo
                btnNuevo.setText("Nuevo");
                tipoOperacion = Operacion.NINGUNO;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    //Método para eliminar un registro
    public void elimnarTipoEmpleado(){
        confirmacion.setTitle("Eliminar Registro");
        confirmacion.setHeaderText("¿Estas seguro de eliminar este registro?\nSe eliminarán todos los registros relacionados con el tipo de empleado");
        confirmacion.setContentText("Código: "+txtCodigoTipoEmpleado.getText());
        Optional<ButtonType> opcion = confirmacion.showAndWait();
        if(opcion.get() == ButtonType.CANCEL){
            informacion.setTitle("Información");
            informacion.setHeaderText("Resultado:");
            informacion.setContentText("Se ha cancelado el proceso");
            informacion.show();
            cargarDatos();
        }else if(opcion.get() == ButtonType.OK){
            try {
                PreparedStatement pS = Conexion.getInstance().getConexion().prepareCall("{call sp_Eliminar_TipoEmpleado(?)}");
                pS.setInt(1, Integer.parseInt(txtCodigoTipoEmpleado.getText()));
                int del = pS.executeUpdate();
                if(del > 0){
                    informacion.setTitle("Eliminar Registro");
                    informacion.setHeaderText("Resultado");
                    informacion.setContentText("El registro ha sido eliminado");
                    informacion.show();
                    cargarDatos();
                }else{
                    error.setTitle("Error");
                    error.setHeaderText("Resultado");
                    error.setContentText("Error al intentar eliminar el registro!!!");
                    error.show();
                    cargarDatos();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    //Método para modificar un registro
    public void modificarTipoEmpleado(){
        if(txtDescripcionTipoEmpleado.getText().equals("")){
            error.setTitle("Error");
            error.setHeaderText("Resultado:");
            error.setContentText("La modificación ha fallado!!\nFaltan datos por ingresar");
            error.show();
        }else{
            try {
                PreparedStatement pS = Conexion.getInstance().getConexion().prepareCall("{call sp_Actualizar_TipoEmpleado(?,?)}");
                pS.setString(1, txtCodigoTipoEmpleado.getText());
                pS.setString(2, txtDescripcionTipoEmpleado.getText());
                int modi = pS.executeUpdate();
                if(modi > 0){
                    informacion.setTitle("Registro modificado");
                    informacion.setHeaderText("Resultado:");
                    informacion.setContentText("El registro se ha modificado con exito");
                    informacion.show();
                    cargarDatos();
                }else{
                    error.setTitle("Error");
                    error.setHeaderText("Resultado:");
                    error.setContentText("Error al intentar modificar el registro!!!");
                    error.show();
                    cargarDatos();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public TipoEmpleado buscarTipoEmpleado(int codigoTipoEmpleado){
        TipoEmpleado resultado = null;
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_TipoEmpleado(?)}");
            procedimiento.setInt(1, codigoTipoEmpleado);
            ResultSet registro = procedimiento.executeQuery();
            while(registro.next()){
                resultado = new TipoEmpleado(registro.getInt("codigoTipoEmpleado"),
                                             registro.getString("descripcion"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }
    
    //Método para buscar datos
    public void buscarTipoEmpleado(){
        try {
            PreparedStatement pS = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_TipoEmpleado(?)}");
            pS.setString(1, txtBuscar.getText());
            ResultSet resultado = pS.executeQuery();
            if(resultado.next()){
                txtCodigoTipoEmpleado.setText(resultado.getString("codigoTipoEmpleado"));
                txtDescripcionTipoEmpleado.setText(resultado.getString("descripcion"));
                desactivarBotones();
            }else{
                error.setTitle("ERROR");
                error.setHeaderText("Error:");
                error.setContentText("No existe un registro con código: "+txtBuscar.getText());
                error.show();
                txtBuscar.setText("");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    //Método para el bonton Cancelar
    public void btnCancelar(){
        txtCodigoTipoEmpleado.setText("");
        txtDescripcionTipoEmpleado.setText("");
        txtBuscar.setText(null);
        
        btnGuardar.setDisable(true);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(false);
        btnNuevo.setDisable(false);
        
        btnCancelar.setVisible(false);
        
        btnEditar.setText("Editar");
        tipoOperacion = Operacion.NINGUNO;
        desactivarTF();
        tblTipoEmpleado.getSelectionModel().clearSelection();
    }
    
        
    //Método para limpiar los TextField y para desactivar botones
    public void limpiarTF(){
        txtCodigoTipoEmpleado.setText("");
        txtDescripcionTipoEmpleado.setText("");
        txtBuscar.setText(null);
        
        btnGuardar.setDisable(true);
        btnReporte.setDisable(false);
        btnEliminar.setDisable(true);
        btnEditar.setDisable(true);
        btnNuevo.setDisable(false);
        
        btnCancelar.setVisible(false);
    }
    
    //Método para limpiar TextField pero con otras instrucciones
    public void limpiarDos(){
        txtCodigoTipoEmpleado.setText("");
        txtDescripcionTipoEmpleado.setText("");
        
        btnGuardar.setDisable(false);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(true);
    }
    
    //Método para activar TextField
    public void activarTF(){
        txtDescripcionTipoEmpleado.setEditable(true);
    }

    //Método para desactivar TextField
    public void desactivarTF(){
        txtDescripcionTipoEmpleado.setEditable(false);
    }
    
    //Método para desactivar Botones
    public void desactivarBotones(){
        btnGuardar.setDisable(true);
        btnEditar.setDisable(false);
        btnEliminar.setDisable(false);
        btnReporte.setDisable(true);
        btnNuevo.setDisable(true);
        
        btnCancelar.setVisible(true);
    }
    
    //Método para comprobar la conexion
    public void estadoConexion(){
        if(Conexion.getInstance().getConexion() != null){
            informacion.setTitle("Conexión");
            informacion.setHeaderText("Resultado");
            informacion.setContentText("Conexión exitosa!!!");
            informacion.show();
        }else{
            error.setTitle("Conexión");
            error.setHeaderText("Resultado");
            error.setContentText("Error de conexión");
            error.show();
        }
    
    }
    
    public void bloquearTamanioCol(){
        colCodigoTipoEmpleado.setResizable(false);
        colDescripcionTipoEmpleado.setResizable(false);
        colCodigoTipoEmpleado.reorderableProperty().set(false);
        colDescripcionTipoEmpleado.reorderableProperty().set(false);
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        desactivarTF();
        seleccionTipoEmpleado();
        cargarDatos();
        bloquearTamanioCol();
    }

    public MainApp getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(MainApp escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
    
    public void menuPrincipal(){
        escenarioPrincipal.menuPrincipal();
    }
    
    public void ventanaEmpleado(){
        escenarioPrincipal.ventanaEmpleado();
    }
}
