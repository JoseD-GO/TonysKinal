package org.josegongora.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import org.josegongora.bd.Conexion;
import org.josegongora.bean.Plato;
import org.josegongora.bean.Producto;
import org.josegongora.bean.ProductosHasPlatos;
import org.josegongora.system.MainApp;

public class ProductoHasPlatoController implements Initializable{
    private MainApp escenariPrincipal;
    
    ObservableList<Plato> listaPlato;
    ObservableList<Producto> listaProducto;
    ObservableList<ProductosHasPlatos> listaProductosPlatos;
    
    @FXML private JFXComboBox cmbCodigoProducto, cmbCodigoPlato;
    
    @FXML private TableView tblProductoHasPlato;
    
    @FXML private TableColumn colCodigoPlato, colCodigoProducto;
    
    @FXML private JFXButton btnLimpiar;
    
    Alert informacion = new Alert(AlertType.INFORMATION);//Creando objetos de tipo Alert para utilizar en toda la clase
    Alert error = new Alert(AlertType.ERROR); //Creando objetos de tipo Alert para utilizar en toda la clase
    
    public void cargarDatos(){
        tblProductoHasPlato.setItems(getProductoPlatos());
        colCodigoPlato.setCellValueFactory(new PropertyValueFactory<ProductosHasPlatos, Integer>("codigoPlato"));
        colCodigoProducto.setCellValueFactory(new PropertyValueFactory<ProductosHasPlatos,Integer>("codigoProducto"));
        cmbCodigoPlato.setItems(getPlato());
        cmbCodigoProducto.setItems(getProducto());
        tblProductoHasPlato.getSelectionModel().clearSelection();
    }
    
    public void seleccionRegistro(){
        tblProductoHasPlato.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<ProductosHasPlatos>(){
            @Override
            public void changed(ObservableValue<? extends ProductosHasPlatos> observable, ProductosHasPlatos valorAnterior, ProductosHasPlatos valorSeleccionado) {
                if(valorSeleccionado != null){
                    cmbCodigoPlato.setValue(buscarPlato(valorSeleccionado.getCodigoPlato()));
                    cmbCodigoProducto.setValue(buscarProducto(valorSeleccionado.getCodigoProducto()));
                    deshabilitarCB();
                }
            }
        });
    }
    
    public ObservableList<Producto> getProducto(){
        ArrayList<Producto> lista = new ArrayList<Producto>();
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Listar_Producto}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new Producto(resultado.getInt("codigoProducto"),
                                        resultado.getString("nombreProducto"),
                                        resultado.getInt("cantidad")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaProducto = FXCollections.observableArrayList(lista);
    }
    
    public ObservableList<Plato> getPlato(){
        ArrayList<Plato> lista = new ArrayList<Plato>();
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Listar_Plato()}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new Plato(resultado.getInt("codigoPlato"),
                                    resultado.getInt("cantidad"),
                                    resultado.getString("nombrePlato"),
                                    resultado.getString("descripcionPlato"),
                                    resultado.getDouble("precioPlato"),
                                    resultado.getInt("codigoTipoPlato")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaPlato = FXCollections.observableArrayList(lista);
    }
    
    public ObservableList<ProductosHasPlatos> getProductoPlatos(){
        ArrayList<ProductosHasPlatos> lista = new ArrayList<ProductosHasPlatos>();
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Listar_Producto_has_Plato()}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new ProductosHasPlatos(resultado.getInt("P.codigoProducto"),
                                                 resultado.getInt("pL.codigoPlato")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaProductosPlatos = FXCollections.observableArrayList(lista);
    }
    
    public Plato buscarPlato(int codigoPlato){
        Plato resultado = null;
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_Plato(?)}");
            procedimiento.setInt(1, codigoPlato);
            ResultSet registro = procedimiento.executeQuery();
            while(registro.next()){
                resultado = new Plato(registro.getInt("codigoPlato"),
                                    registro.getInt("cantidad"),
                                    registro.getString("nombrePlato"),
                                    registro.getString("descripcionPlato"),
                                    registro.getDouble("precioPlato"),
                                    registro.getInt("codigoTipoPlato"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }
    
    public Producto buscarProducto(int codigoProducto){
       Producto resultado = null;
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_Producto(?)}");
            procedimiento.setInt(1, codigoProducto);
            ResultSet registro = procedimiento.executeQuery();
            while(registro.next()){
                resultado = new Producto(registro.getInt("codigoProducto"),
                                         registro.getString("nombreProducto"),
                                         registro.getInt("cantidad"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }
    
    public void deshabilitarCB(){
        cmbCodigoPlato.setDisable(true);
        cmbCodigoProducto.setDisable(true);
        cmbCodigoPlato.setEditable(true);
        cmbCodigoProducto.setEditable(true);
        btnLimpiar.setVisible(true);
    }
    
    public void btnLimpiar(){
        cmbCodigoPlato.getSelectionModel().select(null);
        cmbCodigoProducto.getSelectionModel().select(null);
        cmbCodigoPlato.setDisable(false);
        cmbCodigoProducto.setDisable(false);
        cmbCodigoPlato.setEditable(false);
        cmbCodigoProducto.setEditable(false);
        tblProductoHasPlato.getSelectionModel().clearSelection();
        btnLimpiar.setVisible(false);
    }
    
    public void bloquearTamanioCol(){
        colCodigoPlato.setResizable(false);
        colCodigoProducto.setResizable(false);
        colCodigoPlato.reorderableProperty().set(false);
        colCodigoProducto.reorderableProperty().set(false);
    }
    
    //Método para comprobar la conexión a la base de datos
    public void estadoConexion(){
        try{
        if(Conexion.getInstance().getConexion() != null){
            informacion.setTitle("Conexión");
            informacion.setHeaderText("Resultado");
            informacion.setContentText("Conexion exitosa!!!");
            informacion.show();
        }else{
            error.setTitle("Conexión");
            error.setHeaderText("Resultado");
            error.setContentText("Error de conexión");
            error.show();
        }
        }catch(Exception e){
            e.printStackTrace();
        }
    }    
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cargarDatos();
        seleccionRegistro();
        bloquearTamanioCol();
    }

    public MainApp getEscenariPrincipal() {
        return escenariPrincipal;
    }

    public void setEscenariPrincipal(MainApp escenariPrincipal) {
        this.escenariPrincipal = escenariPrincipal;
    }
    
    public void menuPrincipal(){
        escenariPrincipal.menuPrincipal();
    }
    
    public void ventanaProducto(){
        escenariPrincipal.ventanaProducto();
    }
    
    public void ventanaPlato(){
        escenariPrincipal.ventanaPlato();
    }
}
