package org.josegongora.controller;


import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.InnerShadow;
import javafx.scene.paint.Color;
import org.josegongora.system.MainApp;

public class DatosPersonalesController implements Initializable {
    private MainApp escenarioPrincipal;
    
    @FXML private Button btnProgramador;
    @FXML private Button btnAdministracion;
    @FXML private Label lblDatos;
    @FXML private Label lblTitulo;
    
    private boolean bandera;
    
    InnerShadow sombra = new InnerShadow();
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
    
    }

    public MainApp getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(MainApp escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
    
    public void menuPrincipal(){
     escenarioPrincipal.menuPrincipal();
    }
    
    public void textoProgramador(){
        lblTitulo.setText("Datos Programador");
        lblDatos.setText("José David Góngora Olmedo\n2019063\n5to Perito en Informatica\nIN5BM\nCorreo:\njdavidgongorao@gmail.com");
        bandera = true;
    }
    
    public void textoAdministracion(){
        lblTitulo.setText("Datos Administración");
        lblDatos.setText("Administración");
        bandera = true;
    }

    public void sombraBtnProgramador(){
        sombra.setColor(Color.BLACK);
        sombra.setHeight(21);
        sombra.setWidth(21);
        sombra.setRadius(10);
        btnProgramador.setEffect(sombra);
        textoProgramador();
        bandera = false;
    }
    
    public void sombraBtnAdministracion(){
        sombra.setColor(Color.BLACK);
        sombra.setHeight(21);
        sombra.setWidth(21);
        sombra.setRadius(10);
        btnAdministracion.setEffect(sombra);
        textoAdministracion();
        bandera = false;
    }
    
    public void quitarSombraBtnProgramador(){
        btnProgramador.setEffect(null);
        if(bandera == false){
            lblDatos.setText("");
            lblTitulo.setText("");
        }
    }
    
    public void quitarSombraBtnAdministracion(){
        btnAdministracion.setEffect(null);
        if(bandera == false){
            lblDatos.setText("");
            lblTitulo.setText("");
        }
    }
    
}
