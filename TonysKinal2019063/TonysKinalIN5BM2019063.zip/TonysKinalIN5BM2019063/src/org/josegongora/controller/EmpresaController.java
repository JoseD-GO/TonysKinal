package org.josegongora.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javax.swing.text.MaskFormatter;
import org.josegongora.system.MainApp;
import org.josegongora.bean.Empresa;
import org.josegongora.bd.Conexion;
import org.josegongora.report.GenerarReporte;


public class EmpresaController implements Initializable {
    private enum Operacion{NUEVO,GUARDAR,ELIMINAR,EDITAR,CARGAR,NINGUNO}
    
    private Operacion tipoOperacion = Operacion.NINGUNO;
    
    private ObservableList<Empresa>listaEmpresa;
    
    private MainApp escenarioPrincipal;
    
    @FXML private TextField txtBuscar;
    
    @FXML private JFXTextField txtCodigoEmpresa, txtNombreEmpresa, txtDireccion, txtTelefono;
    
    @FXML private JFXButton btnGuardar,btnNuevo, btnEditar, btnEliminar, btnReporte, btnCancelar;
   
    @FXML private TableView tblEmpresa;
    
    @FXML private TableColumn colCodigoEmpresa, colNombreEmpresa, colDireccion, colTelefono;
    
    @FXML private ImageView imgNuevo;
    
    Alert error = new Alert(AlertType.ERROR); //Creando objetos de tipo Alert para utilizar en toda la clase
    Alert informacion = new Alert(AlertType.INFORMATION);//Creando objetos de tipo Alert para utilizar en toda la clase
    Alert confirmacion  = new Alert(AlertType.CONFIRMATION);//Creando objetos de tipo Alert para utilizar en toda la clase
    
    //Método para ejecutar el procedimiento almacenado 
    public ObservableList<Empresa> getEmpresa(){
        ArrayList<Empresa> lista = new ArrayList<Empresa>();
        try{
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Listar_Empresa()}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new Empresa(resultado.getInt("codigoEmpresa"), 
                resultado.getString("nombreEmpresa"),
                resultado.getString("direccion"),
                resultado.getString("telefono")));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return listaEmpresa = FXCollections.observableArrayList(lista);
    }
    
    
    //Método para cargar los datos a la vista
    public void cargarDatos(){
        tblEmpresa.setItems(getEmpresa());
        colCodigoEmpresa.setCellValueFactory(new PropertyValueFactory<Empresa,Integer>("codigoEmpresa"));
        colNombreEmpresa.setCellValueFactory(new PropertyValueFactory<Empresa, String>("nombreEmpresa"));
        colDireccion.setCellValueFactory(new PropertyValueFactory<Empresa, String>("direccion"));
        colTelefono.setCellValueFactory(new PropertyValueFactory<Empresa, String>("telefono"));
        //colCodigoEmpresa.setStyle("-fx-alignment: CENTER");
        limpiarTF();
        tblEmpresa.getSelectionModel().clearSelection();
    }
    
    
    public void seleccionEmpresa(){
        tblEmpresa.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Empresa>(){
            @Override
            public void changed(ObservableValue<? extends Empresa> observable, Empresa valorAnterior, Empresa valorSeleccionado) {
                if(valorSeleccionado!=null){
                txtCodigoEmpresa.setText(String.valueOf(valorSeleccionado.getCodigoEmpresa()));
                txtNombreEmpresa.setText(valorSeleccionado.getNombreEmpresa());
                txtDireccion.setText(valorSeleccionado.getDireccion());
                txtTelefono.setText(valorSeleccionado.getTelefono());
                desactivarBotones();
                desactivarTF();
                }
            }
        
        }
        );
    }

    
    //Método para guardar datos
    public void guardarDatos(){
        Empresa nueva = new Empresa();
        nueva.setNombreEmpresa(txtNombreEmpresa.getText());
        nueva.setDireccion(txtDireccion.getText());
        nueva.setTelefono(txtTelefono.getText());
        if(nueva.getNombreEmpresa().equals("")||nueva.getDireccion().equals("")||nueva.getTelefono().equals("")){
            error.setTitle("ERROR");
            error.setContentText("El registro ha fallado!!\nFaltan datos por ingresar");
            error.setHeaderText("Resultado:");
            error.show();
        }else{
                try {
                    PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Agregar_Empresa(?,?,?)}");
                    procedimiento.setString(1, nueva.getNombreEmpresa());
                    procedimiento.setString(2, nueva.getDireccion());
                    procedimiento.setString(3, nueva.getTelefono());
                    procedimiento.executeUpdate();
                    listaEmpresa.add(nueva);
                    if(nueva != null){
                        informacion.setTitle("Registro agregado");
                        informacion.setContentText("El registro se ha completado con exito");
                        informacion.setHeaderText("Resultado:");
                        informacion.show();
                        cargarDatos();
                        desactivarTF();
                    }
                    Image imagen = new Image(getClass().getResourceAsStream("/org/josegongora/img/nuevo.png"));//Creando un objeto de tipo Image
                    imgNuevo.setImage(imagen);//Cambiando la imagen del boton nuevo
                    btnNuevo.setText("Nuevo");
                    tipoOperacion = Operacion.NINGUNO;
                } catch (Exception e) {
                    e.printStackTrace();
                }
            
        }
        
    }
 
    //Metodo para eliminar empresa
    public void eliminarEmpresa(){
        confirmacion.setTitle("Eliminar Registro");
        confirmacion.setHeaderText("¿Estas seguro de eliminar este registro?\nSe eliminarán todos los registros relacionados con la empresa");
        confirmacion.setContentText("Código: "+txtCodigoEmpresa.getText());
        Optional<ButtonType> opcion = confirmacion.showAndWait();
        if(opcion.get() == ButtonType.CANCEL){
                  informacion.setTitle("Información");
                  informacion.setContentText("Se ha cancelado el proceso.");
                  informacion.setHeaderText("Resultado:");
                  informacion.show();
                  cargarDatos();
        }else if(opcion.get() == ButtonType.OK){
            try {
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Eliminar_Empresa(?)}");
                procedimiento.setInt(1, Integer.parseInt(txtCodigoEmpresa.getText()));
                int eli = procedimiento.executeUpdate();
                if(eli > 0){
                  informacion.setTitle("Registro Eliminado");
                  informacion.setContentText("El registro se ha eliminado con exito");
                  informacion.setHeaderText("Resultado:");
                  informacion.show();
                  cargarDatos();
                }else{
                  error.setTitle("Error");
                  error.setContentText("Error al intentar eliminar registro!!!");
                  error.setHeaderText("Resultado:");
                  error.show();
                  cargarDatos();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }                 
        }
    }

    //Metodo para modificar datos
    public void modificarDatos(){
        if(txtNombreEmpresa.getText().equals("")||txtDireccion.getText().equals("")||txtTelefono.getText().equals("")){
                error.setTitle("ERROR");
                error.setContentText("La modificación ha fallado!!\nFaltan datos por ingresar");
                error.setHeaderText("Resultado:");
                error.show();       
        }else{              
            try {
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Actualizar_Empresa(?,?,?,?)}");
                procedimiento.setString(1, txtCodigoEmpresa.getText());
                procedimiento.setString(2, txtNombreEmpresa.getText());
                procedimiento.setString(3, txtDireccion.getText());
                procedimiento.setString(4, txtTelefono.getText());
                int res = procedimiento.executeUpdate();
                if(res > 0){
                  informacion.setTitle("Registro Modificado");
                  informacion.setContentText("El registro se ha modificado con exito");
                  informacion.setHeaderText("Resultado:");
                  informacion.show();
                  cargarDatos();
                }else{
                  error.setTitle("Error");
                  error.setContentText("Error al intentar modificar el registro!!!");
                  error.setHeaderText("Resultado:");
                  error.show();
                  cargarDatos();
                }     
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        
    }
    
    /*public void generarReporte(){
        imprimirReporte();
    }*/
    
    public void imprimirReporte(){
        Map parametros = new HashMap();
        parametros.put("codigoEmpresa", null);
        GenerarReporte.mostrarReporte("ReporteEmpresas.jasper","Reporte de Empresas", parametros);
    }
    
    //Método para buscar empresa desde otra clase
    public Empresa buscarEmpresa(int codigoEmpresa){
        Empresa resultado = null;
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_Empresa(?)}");
            procedimiento.setInt(1, codigoEmpresa);
            ResultSet registro = procedimiento.executeQuery();
            while(registro.next()){
                resultado = new Empresa(registro.getInt("codigoEmpresa"),
                                        registro.getString("nombreEmpresa"),
                                        registro.getString("direccion"),
                                        registro.getString("telefono"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }
    
    //Método para buscar datos y colocarlos en los TextField
    public void buscarDatos(){
        Empresa busqueda = new Empresa();
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_Empresa(?)}");
            procedimiento.setString(1, txtBuscar.getText());
            ResultSet resultado = procedimiento.executeQuery();
            if(resultado.next()){
                txtCodigoEmpresa.setText(resultado.getString("codigoEmpresa"));
                txtNombreEmpresa.setText(resultado.getString("nombreEmpresa"));
                txtDireccion.setText(resultado.getString("direccion"));
                txtTelefono.setText(resultado.getString("telefono"));
                desactivarBotones();
            }else{
                error.setTitle("ERROR");
                error.setHeaderText("Error:");
                error.setContentText("No existe un registro con codigo: "+txtBuscar.getText());
                error.show();
                txtBuscar.setText("");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
    //Método para comprobar la conexión a la base de datos
    public void estadoConexion(){
        try{
        if(Conexion.getInstance().getConexion() != null){
            informacion.setTitle("Conexión");
            informacion.setHeaderText("Resultado");
            informacion.setContentText("Conexion exitosa!!!");
            informacion.show();
        }else{
            error.setTitle("Conexión");
            error.setHeaderText("Resultado");
            error.setContentText("Error de conexión");
            error.show();
        }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    //Método para el boton neuvo con ENUMERACIÓN
    public void btnNuevo(){
        switch(tipoOperacion){
            case NINGUNO:
                Image img = new Image(getClass().getResourceAsStream("/org/josegongora/img/cancelar.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(img);//Cambiando la imagen del boton nuevo                
                btnGuardar.setDisable(true);
                btnNuevo.setText("Cancelar");
                activarTF();
                limpiarDos();
                tipoOperacion = Operacion.GUARDAR;
                break;
            case GUARDAR:
                Image imagen = new Image(getClass().getResourceAsStream("/org/josegongora/img/nuevo.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(imagen);//Cambiando la imagen del boton nuevo                
                btnGuardar.setDisable(false);
                btnNuevo.setText("Nuevo");
                limpiarTF();
                desactivarTF();
                tipoOperacion = Operacion.NINGUNO;
                break;
        }
    }
    
    public void btnEditar(){
        switch(tipoOperacion){
            case NINGUNO:
                activarTF();
                btnEliminar.setDisable(true);
                btnReporte.setDisable(true);
                btnEditar.setText("Guardar");
                tipoOperacion = Operacion.EDITAR;
                break;
            case EDITAR:
                modificarDatos();
                btnEditar.setText("Editar");
                tipoOperacion = Operacion.NINGUNO;
                break;
        }
    }
    
    //Método para el boton de cancelar y ocultarlo de nuevo
    public void btnCancelar(){
        txtCodigoEmpresa.setText("");
        txtNombreEmpresa.setText("");
        txtDireccion.setText("");
        txtTelefono.setText("");
        txtBuscar.setText(null);
        
        btnGuardar.setDisable(true);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(false);
        btnNuevo.setDisable(false);
        
        btnCancelar.setVisible(false);
    
        tipoOperacion = Operacion.NINGUNO;
        btnEditar.setText("Editar");
        desactivarTF();
        tblEmpresa.getSelectionModel().clearSelection();
    }
    
    
    //Método para limpiar Textfields y deshabilitar/habilitar botones 
    public void limpiarTF(){
        txtCodigoEmpresa.setText("");
        txtNombreEmpresa.setText("");
        txtDireccion.setText("");
        txtTelefono.setText("");
        txtBuscar.setText(null);
        
        btnGuardar.setDisable(true);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(false);
        btnNuevo.setDisable(false);
        
        btnCancelar.setVisible(false);
        
    }
    
    //Método para limpiar datos pero con otras instrucciones
    public void limpiarDos(){
        txtCodigoEmpresa.setText("");
        txtNombreEmpresa.setText("");
        txtDireccion.setText("");
        txtTelefono.setText("");
        txtBuscar.setText(null);
        
        btnGuardar.setDisable(false);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(true);
    }
    
    //Método para activar los TextField
    public void activarTF(){
        txtDireccion.setEditable(true);
        txtNombreEmpresa.setEditable(true);
        txtTelefono.setEditable(true);
    }
    
    //Método para desactivar los TextField
    public void desactivarTF(){
        txtDireccion.setEditable(false);
        txtNombreEmpresa.setEditable(false);
        txtTelefono.setEditable(false);
    }
    
    //Método para desactivar botones y hacer visible el boton cancelar
    public void desactivarBotones(){
        btnGuardar.setDisable(true);
        btnEditar.setDisable(false);
        btnEliminar.setDisable(false);
        btnReporte.setDisable(true);
        btnNuevo.setDisable(true);
        
        btnCancelar.setVisible(true);
    }
    
    public void ventanaPresupuestos(){
        escenarioPrincipal.ventanaPresupuesto();
    }
    
    public void ventanaServicios(){
        escenarioPrincipal.ventanaServicio();
    }
    
    public void bloquearTamanioCol(){
        colCodigoEmpresa.setResizable(false);
        colDireccion.setResizable(false);
        colNombreEmpresa.setResizable(false);
        colTelefono.setResizable(false);
        colCodigoEmpresa.reorderableProperty().set(false);
        colDireccion.reorderableProperty().set(false);
        colNombreEmpresa.reorderableProperty().set(false);
        colTelefono.reorderableProperty().set(false);
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        //Todo lo que se programa aca se va a ejecutar al cargar la vista
        desactivarTF();
        seleccionEmpresa();
        cargarDatos();
        bloquearTamanioCol();
    }

    public MainApp getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(MainApp escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
    
    public void menuPrincipal(){
        escenarioPrincipal.menuPrincipal();
    }
    
    
}
