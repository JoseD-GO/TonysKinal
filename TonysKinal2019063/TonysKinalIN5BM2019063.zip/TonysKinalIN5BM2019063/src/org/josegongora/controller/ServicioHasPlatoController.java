package org.josegongora.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import org.josegongora.bd.Conexion;
import org.josegongora.bean.Plato;
import org.josegongora.bean.Servicio;
import org.josegongora.bean.ServicioHasPlato;
import org.josegongora.system.MainApp;


public class ServicioHasPlatoController implements Initializable{
    private MainApp escenarioPrincipal;
    
    @FXML private JFXComboBox cmbCodigoServicio, cmbCodigoPlato;
    
    @FXML private TableView tblServicioHasPlato;
    
    @FXML private TableColumn colCodigoServicio, colCodigoPlato;
    
    @FXML private JFXButton btnLimpiar;
    
    private ObservableList<ServicioHasPlato> listaServiciohasPlato;
    private ObservableList<Servicio> listaServicio;
    private ObservableList<Plato> listaPlato;
    
    Alert informacion = new Alert(AlertType.INFORMATION);//Creando objetos de tipo Alert para utilizar en toda la clase
    Alert error = new Alert(AlertType.ERROR); //Creando objetos de tipo Alert para utilizar en toda la clase
    
    public void cargarDatos(){
        tblServicioHasPlato.setItems(getServiciosPlatos());
        colCodigoServicio.setCellValueFactory(new PropertyValueFactory<ServicioHasPlato, Integer>("codigoServicio"));
        colCodigoPlato.setCellValueFactory(new PropertyValueFactory<ServicioHasPlato,Integer>("codigoPlato"));
        cmbCodigoServicio.setItems(getServicio());
        cmbCodigoPlato.setItems(getPlato());
        tblServicioHasPlato.getSelectionModel().clearSelection();
    }
    
    public void seleccionarRegistro(){
        tblServicioHasPlato.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<ServicioHasPlato>(){

            @Override
            public void changed(ObservableValue<? extends ServicioHasPlato> observable, ServicioHasPlato valorAnterior, ServicioHasPlato valorSeleccionado) {
                if(valorSeleccionado != null){
                    cmbCodigoPlato.setValue(buscarPlato(valorSeleccionado.getCodigoPlato()));
                    cmbCodigoServicio.setValue(buscarServicio(valorSeleccionado.getCodigoServicio()));
                    deshabilitarCB();
                }
            }
        });
    }
    
    public ObservableList<Servicio> getServicio(){
        ArrayList<Servicio> lista = new ArrayList<Servicio>();
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Listar_Servicio()}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new Servicio(resultado.getInt("codigoServicio"),
                            resultado.getDate("fecha_Servicio"),
                            resultado.getString("tipo_Servicio"),
                            resultado.getString("horaServicio"),
                            resultado.getString("lugarServicio"),
                            resultado.getString("telefonoContacto"),
                            resultado.getInt("codigoEmpresa")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return  listaServicio = FXCollections.observableArrayList(lista);
    }
    
    public Plato buscarPlato(int codigoPlato){
        Plato resultado = null;
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_Plato(?)}");
            procedimiento.setInt(1, codigoPlato);
            ResultSet registro = procedimiento.executeQuery();
            while(registro.next()){
                resultado = new Plato(registro.getInt("codigoPlato"),
                                    registro.getInt("cantidad"),
                                    registro.getString("nombrePlato"),
                                    registro.getString("descripcionPlato"),
                                    registro.getDouble("precioPlato"),
                                    registro.getInt("codigoTipoPlato"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }
    
    public ObservableList<Plato> getPlato(){
        ArrayList<Plato> lista = new ArrayList<Plato>();
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Listar_Plato()}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new Plato(resultado.getInt("codigoPlato"),
                                    resultado.getInt("cantidad"),
                                    resultado.getString("nombrePlato"),
                                    resultado.getString("descripcionPlato"),
                                    resultado.getDouble("precioPlato"),
                                    resultado.getInt("codigoTipoPlato")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaPlato = FXCollections.observableArrayList(lista);
    }
        
    //Método para buscar servicio desde otra clase
    public Servicio buscarServicio(int codigoServicio){
        Servicio resultado = null;
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_Servicio(?)}");
            procedimiento.setInt(1, codigoServicio);
            ResultSet registro = procedimiento.executeQuery();
            while(registro.next()){
                resultado = new Servicio(registro.getInt("codigoServicio"),
                            registro.getDate("fecha_Servicio"),
                            registro.getString("tipo_Servicio"),
                            registro.getString("horaServicio"),
                            registro.getString("lugarServicio"),
                            registro.getString("telefonoContacto"),
                            registro.getInt("codigoEmpresa"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }
        
    public ObservableList<ServicioHasPlato> getServiciosPlatos(){
        ArrayList<ServicioHasPlato> lista = new ArrayList<ServicioHasPlato>();
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Listar_Servicio_has_Plato()}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new ServicioHasPlato(resultado.getInt("codigoPlato"),
                                               resultado.getInt("codigoServicio")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaServiciohasPlato = FXCollections.observableArrayList(lista);
    }
    
    public void deshabilitarCB(){
        cmbCodigoPlato.setDisable(true);
        cmbCodigoServicio.setDisable(true);
        cmbCodigoPlato.setEditable(true);
        cmbCodigoServicio.setEditable(true);
        btnLimpiar.setVisible(true);
    }
    
    public void btnLimpiar(){
        cmbCodigoPlato.getSelectionModel().select(null);
        cmbCodigoServicio.getSelectionModel().select(null);
        cmbCodigoPlato.setDisable(false);
        cmbCodigoServicio.setDisable(false);
        cmbCodigoPlato.setEditable(false);
        cmbCodigoServicio.setEditable(false);
        tblServicioHasPlato.getSelectionModel().clearSelection();
        btnLimpiar.setVisible(false);
    }
    
    public void bloquearTamanioCol(){
        colCodigoPlato.setResizable(false);
        colCodigoServicio.setResizable(false);
        colCodigoPlato.reorderableProperty().set(false);
        colCodigoServicio.reorderableProperty().set(false);
    }
    
    //Método para comprobar la conexión a la base de datos
    public void estadoConexion(){
        try{
        if(Conexion.getInstance().getConexion() != null){
            informacion.setTitle("Conexión");
            informacion.setHeaderText("Resultado");
            informacion.setContentText("Conexion exitosa!!!");
            informacion.show();
        }else{
            error.setTitle("Conexión");
            error.setHeaderText("Resultado");
            error.setContentText("Error de conexión");
            error.show();
        }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cargarDatos();
        seleccionarRegistro();
        bloquearTamanioCol();
    }

    public MainApp getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(MainApp escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
    
    public void menuPrincipal(){
        escenarioPrincipal.menuPrincipal();
    }
    
    public void ventanaServicio(){
        escenarioPrincipal.ventanaServicio();
    }
    
    public void ventanaPlato(){
        escenarioPrincipal.ventanaPlato();
    }
}
