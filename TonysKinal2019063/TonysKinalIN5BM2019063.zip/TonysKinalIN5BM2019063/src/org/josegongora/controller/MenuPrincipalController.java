package org.josegongora.controller;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.fxml.Initializable;
import javafx.scene.control.TextInputDialog;
import org.josegongora.report.GenerarReporte;
import org.josegongora.system.MainApp;

public class MenuPrincipalController implements Initializable {
    private MainApp escenarioPrincipal;
    
    TextInputDialog pedir = new TextInputDialog();
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        
    }
    
    public MainApp getEscenarioPrincipal(){
        return escenarioPrincipal;
    }
    
    public void setEscenarioPrincipal(MainApp escenarioPrincipal){
        this.escenarioPrincipal = escenarioPrincipal;
    }
    
    public void ventanaProgramador(){
        escenarioPrincipal.ventanaProgramador();
    }
    
    public void ventanaEmpresa(){
        escenarioPrincipal.ventanaEmpresa();
    }
    
    public void ventanaPresupuesto(){
        escenarioPrincipal.ventanaPresupuesto();
    }
    
    public void ventanaServicio(){
        escenarioPrincipal.ventanaServicio();
    }
    
    public void ventanaTipoEmpleado(){
        escenarioPrincipal.ventanaTipoEmpleado();
    }
    
    public void ventanaEmpleado(){
        escenarioPrincipal.ventanaEmpleado();
    }
    
    public void ventanaTipoPlato(){
        escenarioPrincipal.ventanaTipoPlato();
    }
    
    public void ventanaProducto(){
        escenarioPrincipal.ventanaProducto();
    }
    
    public void ventanaPlato(){
        escenarioPrincipal.ventanaPlato();
    }
    
    public void ventanaServicioHasPlato(){
        escenarioPrincipal.ventanaServicioHasPlato();
    }
    
    public void ventanaProductoHasPlato(){
        escenarioPrincipal.ventanaProductoHasPlato();
    }
    
    public void ventananServicioHasEmpleado(){
        escenarioPrincipal.ventananServicioHasEmpleado();
    }
    
    public void imprimirReporteEmpresas(){
        Map parametros = new HashMap();
        parametros.put("codEmpresa",null);
        GenerarReporte.mostrarReporte("ReporteEmpresas.jasper", "Reporte de Empresas", parametros);
    }
    
    public void imprimirReportePresupuestos(){
        try {
            Map parametros = new HashMap();
        
            pedir.setTitle("Reporte de Presupuesto");
            pedir.setHeaderText(null);
            pedir.setContentText("Ingrese el código de empresa: ");
            Optional<String> codigo = pedir.showAndWait();

            String codEmpresa = codigo.get();
            parametros.put("codEmpresa", Integer.valueOf(codEmpresa));
            GenerarReporte.mostrarReporte("ReportePresupuestos.jasper", "Reporte de Presupuestos", parametros);
        } catch (Exception e) {    
        }    
    }
    
    public void imprimirReporteServicios(){
        try {
            Map parametros = new HashMap();
            pedir.setTitle("Reporte de Servicio");
            pedir.setHeaderText(null);
            pedir.setContentText("Ingrese el código de servicio:");
            Optional<String> codigo = pedir.showAndWait();
            
            int codServicio = Integer.valueOf(codigo.get());
            parametros.put("codServicio", codServicio);
            GenerarReporte.mostrarReporte("ReporteServicios.jasper", "Reporte de Servicio", parametros);
        } catch (Exception e) {
        }
    }
}
