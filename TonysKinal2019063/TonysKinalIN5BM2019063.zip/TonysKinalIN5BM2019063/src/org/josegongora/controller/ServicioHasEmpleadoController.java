package org.josegongora.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.controls.JFXTimePicker;
import eu.schudt.javafx.controls.calendar.DatePicker;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import org.josegongora.bd.Conexion;
import org.josegongora.bean.Empleado;
import org.josegongora.bean.Servicio;
import org.josegongora.bean.ServicioHasEmpleado;
import org.josegongora.system.MainApp;


public class ServicioHasEmpleadoController implements Initializable{
    private MainApp escenarioPrincipal;
    
    private enum Operacion{NUEVO,GUARDAR,ELIMINAR,EDITAR,CARGAR,NINGUNO}
    private Operacion tipoOperacion = Operacion.NINGUNO;
    
    @FXML private JFXButton btnNuevo, btnGuardar, btnEliminar, btnEditar, btnReporte, btnCancelar;
    
    @FXML private JFXTextField txtCodigo, txtLugarEvento;
    
    @FXML private JFXComboBox cmbCodigoServicio, cmbCodigoEmpleado;
    
    @FXML private ImageView imgNuevo;
    
    @FXML private TextField txtBuscar;
    
    private DatePicker fechaEvento;
    
    @FXML private GridPane grpFechaEvento;
    
    @FXML private JFXTimePicker tmpHoraEvento;
    
    @FXML private TableView tblServicioHasEmpleado;
    
    @FXML private TableColumn colCodigo, colCodigoServicio, colCodigoEmpleado, colFecha, colHora, colLugar;
    
    private ObservableList<ServicioHasEmpleado> listaServicioHasEmpleado;
    private ObservableList<Servicio> listaServicio;
    private ObservableList<Empleado> listaEmpleado;
    
    Alert error = new Alert(AlertType.ERROR); //Creando objetos de tipo Alert para utilizar en toda la clase
    Alert informacion = new Alert(AlertType.INFORMATION);//Creando objetos de tipo Alert para utilizar en toda la clase
    Alert confirmacion  = new Alert(AlertType.CONFIRMATION);//Creando objetos de tipo Alert para utilizar en toda la clase
    
    public void cargarDatos(){
        tblServicioHasEmpleado.setItems(getServicioHasEmpleado());
        colCodigo.setCellValueFactory(new PropertyValueFactory<ServicioHasEmpleado, Integer>("Servicios_codigoServicio"));
        colCodigoServicio.setCellValueFactory(new PropertyValueFactory<ServicioHasEmpleado, Integer>("codigoServicio"));
        colCodigoEmpleado.setCellValueFactory(new PropertyValueFactory<ServicioHasEmpleado, Integer>("codigoEmpleado"));
        colFecha.setCellValueFactory(new PropertyValueFactory<ServicioHasEmpleado, Date>("fechaEvento"));
        colHora.setCellValueFactory(new PropertyValueFactory<ServicioHasEmpleado, String>("horaEvento"));
        colLugar.setCellValueFactory(new PropertyValueFactory<ServicioHasEmpleado, String>("lugarEvento"));
        cmbCodigoServicio.setItems(getServicio());
        cmbCodigoEmpleado.setItems(getEmpleado());
        cmbCodigoServicio.setEditable(true);
        cmbCodigoEmpleado.setEditable(true);
        limpiarTF();
        tblServicioHasEmpleado.getSelectionModel().clearSelection();
    }
    
    public void seleccionDatos(){
        tblServicioHasEmpleado.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<ServicioHasEmpleado>(){
            
            @Override
            public void changed(ObservableValue<? extends ServicioHasEmpleado> observable, ServicioHasEmpleado valorAnterior, ServicioHasEmpleado valorSeleccionado) {
                if(valorSeleccionado != null){
                    txtCodigo.setText(String.valueOf(valorSeleccionado.getServicios_codigoServicio()));
                    cmbCodigoServicio.setValue(buscarServicio(valorSeleccionado.getCodigoServicio()));
                    cmbCodigoEmpleado.setValue(buscarEmpleado(valorSeleccionado.getCodigoEmpleado()));
                    fechaEvento.selectedDateProperty().set(valorSeleccionado.getFechaEvento());
                    tmpHoraEvento.setValue(LocalTime.parse(valorSeleccionado.getHoraEvento()));
                    txtLugarEvento.setText(String.valueOf(valorSeleccionado.getLugarEvento()));
                    desactivarBotones();
                    desactivarTF();
                }
            }


        });
    }
    
    public ObservableList<ServicioHasEmpleado> getServicioHasEmpleado(){
        ArrayList<ServicioHasEmpleado> lista = new ArrayList<ServicioHasEmpleado>();
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Listar_Servicio_has_Empleado()}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new ServicioHasEmpleado(resultado.getInt("Servicios_codigoServicio"),
                                                  resultado.getInt("codigoServicio"),
                                                  resultado.getInt("codigoEmpleado"),
                                                  resultado.getDate("fechaEvento"),
                                                  resultado.getString("horaEvento"),
                                                  resultado.getString("lugarEvento")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaServicioHasEmpleado = FXCollections.observableArrayList(lista);
    }
    
    public ObservableList<Servicio> getServicio(){
        ArrayList<Servicio> lista = new ArrayList<Servicio>();
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Listar_Servicio()}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new Servicio(resultado.getInt("codigoServicio"),
                            resultado.getDate("fecha_Servicio"),
                            resultado.getString("tipo_Servicio"),
                            resultado.getString("horaServicio"),
                            resultado.getString("lugarServicio"),
                            resultado.getString("telefonoContacto"),
                            resultado.getInt("codigoEmpresa")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return  listaServicio = FXCollections.observableArrayList(lista);
    }
        
    public ObservableList<Empleado> getEmpleado(){
        ArrayList<Empleado> lista = new ArrayList<Empleado>();
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Listar_Empleado()}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new Empleado (resultado.getInt("codigoEmpleado"),
                resultado.getInt("numeroEmpleado"),
                resultado.getString("apellidosEmpleado"),
                resultado.getString("nombreEmpleado"),
                resultado.getString("direccion"),
                resultado.getString("telefonoContacto"),
                resultado.getString("gradoCocinero"),
                resultado.getInt("codigoTipoEmpleado")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaEmpleado = FXCollections.observableArrayList(lista);
    }
    
    //Método para buscar servicio desde otra clase
    public Servicio buscarServicio(int codigoServicio){
        Servicio resultado = null;
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_Servicio(?)}");
            procedimiento.setInt(1, codigoServicio);
            ResultSet registro = procedimiento.executeQuery();
            while(registro.next()){
                resultado = new Servicio(registro.getInt("codigoServicio"),
                            registro.getDate("fecha_Servicio"),
                            registro.getString("tipo_Servicio"),
                            registro.getString("horaServicio"),
                            registro.getString("lugarServicio"),
                            registro.getString("telefonoContacto"),
                            registro.getInt("codigoEmpresa"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }
    
        //Método para buscar empleado desde otra clase
    public Empleado buscarEmpleado(int codigoEmpleado){
        Empleado resultado = null;
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_Empleado(?)}");
            procedimiento.setInt(1, codigoEmpleado);
            ResultSet registro = procedimiento.executeQuery();
            while(registro.next()){
                resultado = new Empleado (registro.getInt("codigoEmpleado"),
                                            registro.getInt("numeroEmpleado"),
                                            registro.getString("apellidosEmpleado"),
                                            registro.getString("nombreEmpleado"),
                                            registro.getString("direccion"),
                                            registro.getString("telefonoContacto"),
                                            registro.getString("gradoCocinero"),
                                            registro.getInt("codigoTipoEmpleado"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }
    
    public void btnNuevo(){
        switch(tipoOperacion){
            case NINGUNO:
                Image img = new Image(getClass().getResourceAsStream("/org/josegongora/img/cancelar.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(img);//Cambiando la imagen del boton nuevo
                btnGuardar.setDisable(false);
                btnNuevo.setText("Cancelar");
                cmbCodigoEmpleado.setEditable(false);
                cmbCodigoServicio.setEditable(false);
                activarTF();
                limpiarDos();
                tipoOperacion = Operacion.GUARDAR;
                break;
            case GUARDAR:
                Image imagen = new Image(getClass().getResourceAsStream("/org/josegongora/img/nuevo.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(imagen);//Cambiando la imagen del boton nuevo
                btnGuardar.setDisable(true);
                btnNuevo.setText("Nuevo");
                fechaEvento.selectedDateProperty().set(null);
                limpiarTF();
                desactivarTF();
                cargarDatos();
                tipoOperacion = Operacion.NINGUNO;
                break;
        }
    }
    
    public void btnEditar(){
        switch(tipoOperacion){
            case NINGUNO:
                txtCodigo.setEditable(false);
                grpFechaEvento.setDisable(false);
                txtLugarEvento.setEditable(true);
                tmpHoraEvento.setDisable(false);
                cmbCodigoEmpleado.setDisable(true);
                cmbCodigoServicio.setDisable(true);
                btnEliminar.setDisable(true);
                btnReporte.setDisable(true);
                btnEditar.setText("Guardar");
                tipoOperacion = Operacion.EDITAR;
                break;
            case EDITAR:
                editarRegistro();
                cmbCodigoEmpleado.getSelectionModel().clearSelection();
                cmbCodigoServicio.getSelectionModel().clearSelection();
                btnEditar.setText("Editar");
                tipoOperacion = Operacion.NINGUNO;
                break;
        }
    }
        
    public void btnCancelar(){
        txtCodigo.setText("");
        txtLugarEvento.setText("");
        tmpHoraEvento.setValue(null);
        fechaEvento.selectedDateProperty().set(null);
        cmbCodigoEmpleado.getSelectionModel().select(null);
        cmbCodigoServicio.getSelectionModel().select(null);
        txtBuscar.setText(null);
        
        btnGuardar.setDisable(true);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(false);
        btnNuevo.setDisable(false);
        
        btnCancelar.setVisible(false);
    
        tipoOperacion = Operacion.NINGUNO;
        btnEditar.setText("Editar");
        
        desactivarTF();
        
        tblServicioHasEmpleado.getSelectionModel().clearSelection();
    }
    
    public void guardarRegistro(){
        if(cmbCodigoServicio.getValue() == null||cmbCodigoEmpleado.getValue() == null||fechaEvento.getSelectedDate() == null|| tmpHoraEvento.getValue() == null||txtLugarEvento.getText().isEmpty()){
            error.setTitle("ERROR");
            error.setContentText("El registro ha fallado!!\nFaltan datos por ingresar");
            error.setHeaderText("Resultado:");
            error.show(); 
        }else{
            ServicioHasEmpleado registro = new ServicioHasEmpleado();
            registro.setCodigoServicio(((Servicio)cmbCodigoServicio.getSelectionModel().getSelectedItem()).getCodigoServicio());
            registro.setCodigoEmpleado(((Empleado)cmbCodigoEmpleado.getSelectionModel().getSelectedItem()).getCodigoEmpleado());
            registro.setFechaEvento(fechaEvento.getSelectedDate());
            registro.setHoraEvento(String.valueOf(tmpHoraEvento.getValue()));
            registro.setLugarEvento(txtLugarEvento.getText());
            try {
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Agregar_ServicioHasEmpleado(?,?,?,?,?)}");
                procedimiento.setInt(1, registro.getCodigoServicio());
                procedimiento.setInt(2, registro.getCodigoEmpleado());
                procedimiento.setDate(3, new java.sql.Date(registro.getFechaEvento().getTime()));
                procedimiento.setString(4, registro.getHoraEvento());
                procedimiento.setString(5, registro.getLugarEvento());
                procedimiento.executeUpdate();
                listaServicioHasEmpleado.add(registro);
                if(registro != null){
                    informacion.setTitle("Registro agregado");
                    informacion.setContentText("El registro se ha completado con exito");
                    informacion.setHeaderText("Resultado:");
                    informacion.show();
                    cargarDatos();
                    desactivarTF();
                }
                Image imagen = new Image(getClass().getResourceAsStream("/org/josegongora/img/nuevo.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(imagen);//Cambiando la imagen del boton nuevo
                btnNuevo.setText("Nuevo");
                tipoOperacion = Operacion.NINGUNO;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public void eliminarRegistro(){
        confirmacion.setTitle("Eliminar Registro");
        confirmacion.setHeaderText("¿Estas seguro de eliminar este registro?");
        confirmacion.setContentText("Código: "+txtCodigo.getText());
        Optional<ButtonType> opcion = confirmacion.showAndWait();
        if(opcion.get() == ButtonType.CANCEL){
           informacion.setTitle("Información");
           informacion.setContentText("Se ha cancelado el proceso.");
           informacion.setHeaderText("Resultado:");
           informacion.show();
           cargarDatos();
        }else if(opcion.get() == ButtonType.OK){
            try {
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Eliminar_ServicioHasEmpleado(?)}");
                procedimiento.setInt(1, Integer.parseInt(txtCodigo.getText()));
                int resultado = procedimiento.executeUpdate();
                if(resultado > 0){
                  informacion.setTitle("Registro Eliminado");
                  informacion.setContentText("El registro se ha eliminado con exito");
                  informacion.setHeaderText("Resultado:");
                  informacion.show();
                  cargarDatos();
                }else{
                  error.setTitle("Error");
                  error.setContentText("Error al intentar eliminar registro!!!");
                  error.setHeaderText("Resultado:");
                  error.show();
                  cargarDatos();
                }
            } catch (Exception e) {
            }
        }
    }
    
    public void editarRegistro(){
        if(cmbCodigoServicio.getValue() == null||cmbCodigoEmpleado.getValue() == null||fechaEvento.getSelectedDate() == null|| tmpHoraEvento.getValue() == null||txtLugarEvento.getText().isEmpty()){
            error.setTitle("ERROR");
            error.setContentText("La modificacion ha fallado!!\nFaltan datos por ingresar");
            error.setHeaderText("Resultado:");
            error.show(); 
        }else{
            try {
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Actualizar_ServicioHasEmpleado(?,?,?,?)}");
                procedimiento.setInt(1, Integer.parseInt(txtCodigo.getText()));
                procedimiento.setDate(2, new java.sql.Date(fechaEvento.getSelectedDate().getTime()));
                procedimiento.setString(3, String.valueOf(tmpHoraEvento.getValue()));
                procedimiento.setString(4, txtLugarEvento.getText());
                int resultado = procedimiento.executeUpdate();
                if(resultado > 0){
                      informacion.setTitle("Registro Modificado");
                      informacion.setContentText("El registro se ha modificado con exito");
                      informacion.setHeaderText("Resultado:");
                      informacion.show();
                      grpFechaEvento.setDisable(true);
                      cargarDatos();
                    }else{
                      error.setTitle("Error");
                      error.setContentText("Error al intentar modificar el registro!!!");
                      error.setHeaderText("Resultado:");
                      error.show();
                      cargarDatos();
                    }     
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public void buscarDatos(){
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_ServicioHasEmpleado(?)}");
            procedimiento.setInt(1, Integer.parseInt(txtBuscar.getText()));
            ResultSet resultado = procedimiento.executeQuery();
            if(resultado.next()){
                txtCodigo.setText(resultado.getString("Servicios_codigoServicio"));
                cmbCodigoEmpleado.setValue((buscarEmpleado(resultado.getInt("codigoEmpleado"))));
                cmbCodigoServicio.setValue(buscarServicio(resultado.getInt("codigoServicio")));
                fechaEvento.selectedDateProperty().set(resultado.getDate("fechaEvento"));
                tmpHoraEvento.setValue(LocalTime.parse(resultado.getString("horaEvento")));
                txtLugarEvento.setText(resultado.getString("lugarEvento"));
                desactivarBotones();
            }else{
                error.setTitle("ERROR");
                error.setHeaderText("Error:");
                error.setContentText("No existe un registro con codigo: "+txtBuscar.getText());
                error.show();
                txtBuscar.setText("");
            }
        } catch (Exception e) {
        }
    }
    
    //Método para limpiar Textfields y deshabilitar/habilitar botones 
    public void limpiarTF(){
        txtCodigo.setText("");
        txtLugarEvento.setText("");
        //fechaServicio.selectedDateProperty().set(null);
        tmpHoraEvento.setValue(null);
        cmbCodigoServicio.getSelectionModel().select(null);
        cmbCodigoEmpleado.getSelectionModel().select(null);
        txtBuscar.setText(null);
        
        btnGuardar.setDisable(true);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(false);
        btnNuevo.setDisable(false);
        
        btnCancelar.setVisible(false);
        
    }
    
    //Método para limpiar datos pero con otras instrucciones
    public void limpiarDos(){
        txtCodigo.setText("");
        txtLugarEvento.setText("");
        tmpHoraEvento.setValue(null);
        //fechaServicio.selectedDateProperty().set(null);
        cmbCodigoServicio.getSelectionModel().select("");
        cmbCodigoEmpleado.getSelectionModel().select("");
        txtBuscar.setText(null);
        
        btnGuardar.setDisable(false);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(true);
    }
    
    //Método para activar los TextField
    public void activarTF(){
        grpFechaEvento.setDisable(false);
        //txtCodigo.setEditable(true);
        txtLugarEvento.setEditable(true);
        tmpHoraEvento.setDisable(false);
        cmbCodigoEmpleado.setEditable(false);
        cmbCodigoEmpleado.setDisable(false);
        cmbCodigoServicio.setEditable(false);
        cmbCodigoServicio.setDisable(false);
    }
    
    //Método para desactivar los TextField
    public void desactivarTF(){
        txtCodigo.setEditable(false);
        grpFechaEvento.setDisable(true);
        txtLugarEvento.setEditable(false);
        tmpHoraEvento.setDisable(true);
        cmbCodigoServicio.setDisable(true);
        cmbCodigoEmpleado.setDisable(true);
    }
    
    //Método para desactivar botones y hacer visible el boton cancelar
    public void desactivarBotones(){
        btnGuardar.setDisable(true);
        btnEditar.setDisable(false);
        btnEliminar.setDisable(false);
        btnReporte.setDisable(true);
        btnNuevo.setDisable(true);
        
        btnCancelar.setVisible(true);
    }
    
    //Método para comprobar la conexión a la base de datos
    public void estadoConexion(){
        try{
        if(Conexion.getInstance().getConexion() != null){
            informacion.setTitle("Conexión");
            informacion.setHeaderText("Resultado");
            informacion.setContentText("Conexion exitosa!!!");
            informacion.show();
        }else{
            error.setTitle("Conexión");
            error.setHeaderText("Resultado");
            error.setContentText("Error de conexión");
            error.show();
        }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void bloquearTamanioCol(){
        colCodigo.setResizable(false);
        colCodigoEmpleado.setResizable(false);
        colCodigoServicio.setResizable(false);
        colFecha.setResizable(false);
        colHora.setResizable(false);
        colLugar.setResizable(false);
        colCodigo.reorderableProperty().set(false);
        colCodigoEmpleado.reorderableProperty().set(false);
        colCodigoServicio.reorderableProperty().set(false);
        colFecha.reorderableProperty().set(false);
        colHora.reorderableProperty().set(false);
        colLugar.reorderableProperty().set(false);
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cargarDatos();
        seleccionDatos();
        desactivarTF();
        bloquearTamanioCol();
        fechaEvento = new DatePicker(Locale.ENGLISH);
        fechaEvento.setDateFormat(new SimpleDateFormat("yyyy-MM-dd"));
        fechaEvento.setId("datePicker");
        fechaEvento.setPromptText("Fecha(yyyy-MM-dd)");
        fechaEvento.getCalendarView().todayButtonTextProperty().set("Hoy");
        fechaEvento.getCalendarView().setShowWeeks(false);
        fechaEvento.getStylesheets().add("org/josegongora/resources/DatePicker.css");
        grpFechaEvento.add(fechaEvento, 0, 0);
    }

    public MainApp getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(MainApp escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
    
    public void menuPrincipal(){
        escenarioPrincipal.menuPrincipal();
    }
    
    public void ventanaServicio(){
        escenarioPrincipal.ventanaServicio();
    }
    
    public void ventanaEmpleado(){
        escenarioPrincipal.ventanaEmpleado();
    }
}
