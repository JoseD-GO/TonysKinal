package org.josegongora.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.controls.JFXTimePicker;
import eu.schudt.javafx.controls.calendar.DatePicker;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import org.josegongora.bd.Conexion;
import org.josegongora.bean.Empresa;
import org.josegongora.bean.Servicio;
import org.josegongora.report.GenerarReporte;
import org.josegongora.system.MainApp;

public class ServicioController implements Initializable{
    private MainApp escenarioPrincipal;
    
    private enum Operacion{NUEVO,GUARDAR,ELIMINAR,EDITAR,CARGAR,NINGUNO}
    private Operacion tipoOperacion = Operacion.NINGUNO;
    
    private ObservableList<Empresa> listaEmpresa;
    private ObservableList<Servicio> listaServicio;
    
    @FXML private JFXButton btnNuevo, btnGuardar, btnEliminar, btnEditar, btnReporte, btnCancelar;
    
    @FXML private JFXTextField txtCodigoServicio, txtTipoServicio, txtLugar, txtTelefono;
    
    @FXML private JFXComboBox cmbCodigoEmpresa;
    
    @FXML private ImageView imgNuevo;
    
    @FXML private TextField txtBuscar;
    
    private DatePicker fechaServicio;
    
    @FXML private GridPane grpFechaServicio;
    
    @FXML private JFXTimePicker tmpHora;
    
    @FXML private TableView tblServicio;
    
    @FXML private TableColumn colCodigoServicio, colFecha, colHora, colTipo, colLugar, colTelefono, colCodigoEmpresa;
    
    Alert error = new Alert(AlertType.ERROR); //Creando objetos de tipo Alert para utilizar en toda la clase
    Alert informacion = new Alert(AlertType.INFORMATION);//Creando objetos de tipo Alert para utilizar en toda la clase
    Alert confirmacion  = new Alert(AlertType.CONFIRMATION);//Creando objetos de tipo Alert para utilizar en toda la clase
    
    
    public void cargarDatos(){
        tblServicio.setItems(getServicio());
        colCodigoServicio.setCellValueFactory(new PropertyValueFactory<Servicio, Integer>("codigoServicio"));
        colFecha.setCellValueFactory(new PropertyValueFactory<Servicio, Date>("fecha_Servicio"));
        colHora.setCellValueFactory(new PropertyValueFactory<Servicio, String>("horaServicio"));
        colTipo.setCellValueFactory(new PropertyValueFactory<Servicio, String>("tipo_Servicio"));
        colLugar.setCellValueFactory(new PropertyValueFactory<Servicio, String>("lugarServicio"));
        colTelefono.setCellValueFactory(new PropertyValueFactory<Servicio, String>("telefonoContacto"));
        colCodigoEmpresa.setCellValueFactory(new PropertyValueFactory<Servicio, Integer>("codigoEmpresa"));
        cmbCodigoEmpresa.setItems(getEmpresa());
        cmbCodigoEmpresa.setEditable(true);
        limpiarTF();
        tblServicio.getSelectionModel().clearSelection();
    }
    
    public void seleccionServicio(){
        tblServicio.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Servicio>(){
            @Override
            public void changed(ObservableValue<? extends Servicio> observable, Servicio valorAnterior, Servicio valorSeleccionado) {
                if(valorSeleccionado != null){
                    txtCodigoServicio.setText(String.valueOf(valorSeleccionado.getCodigoServicio()));
                    fechaServicio.selectedDateProperty().set(valorSeleccionado.getFecha_Servicio());
                    tmpHora.setValue(LocalTime.parse(valorSeleccionado.getHoraServicio()));
                    txtTipoServicio.setText(valorSeleccionado.getTipo_Servicio());
                    txtLugar.setText(valorSeleccionado.getLugarServicio());
                    txtTelefono.setText(valorSeleccionado.getTelefonoContacto());
                    cmbCodigoEmpresa.setValue(buscarEmpresa(valorSeleccionado.getCodigoEmpresa()));
                    desactivarBotones();
                    desactivarTF();
                }
            }
        
        
            }
        );
    }
    
    public ObservableList<Servicio> getServicio(){
        ArrayList<Servicio> lista = new ArrayList<Servicio>();
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Listar_Servicio()}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new Servicio(resultado.getInt("codigoServicio"),
                            resultado.getDate("fecha_Servicio"),
                            resultado.getString("tipo_Servicio"),
                            resultado.getString("horaServicio"),
                            resultado.getString("lugarServicio"),
                            resultado.getString("telefonoContacto"),
                            resultado.getInt("codigoEmpresa")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return  listaServicio = FXCollections.observableArrayList(lista);
    }
    
    //Método para ejecutar el procedimiento almacenado 
    public ObservableList<Empresa> getEmpresa(){
        ArrayList<Empresa> lista = new ArrayList<Empresa>();
        try{
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Listar_Empresa()}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new Empresa(resultado.getInt("codigoEmpresa"), 
                resultado.getString("nombreEmpresa"),
                resultado.getString("direccion"),
                resultado.getString("telefono")));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return listaEmpresa = FXCollections.observableArrayList(lista);
    }
    
    //Método para buscar empresa desde otra clase
    public Empresa buscarEmpresa(int codigoEmpresa){
        Empresa resultado = null;
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_Empresa(?)}");
            procedimiento.setInt(1, codigoEmpresa);
            ResultSet registro = procedimiento.executeQuery();
            while(registro.next()){
                resultado = new Empresa(registro.getInt("codigoEmpresa"),
                                        registro.getString("nombreEmpresa"),
                                        registro.getString("direccion"),
                                        registro.getString("telefono"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }
    
    public void btnNuevo(){
        switch(tipoOperacion){
            case NINGUNO:
                Image img = new Image(getClass().getResourceAsStream("/org/josegongora/img/cancelar.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(img);//Cambiando la imagen del boton nuevo
                btnGuardar.setDisable(false);
                btnNuevo.setText("Cancelar");
                cmbCodigoEmpresa.setEditable(false);
                activarTF();
                limpiarDos();
                tipoOperacion = Operacion.GUARDAR;
                break;
            case GUARDAR:
                Image imagen = new Image(getClass().getResourceAsStream("/org/josegongora/img/nuevo.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(imagen);//Cambiando la imagen del boton nuevo
                btnGuardar.setDisable(true);
                btnNuevo.setText("Nuevo");
                fechaServicio.selectedDateProperty().set(null);
                limpiarTF();
                desactivarTF();
                cargarDatos();
                tipoOperacion = Operacion.NINGUNO;
                break;
        }
    }
    
    public void btnEditar(){
        switch(tipoOperacion){
            case NINGUNO:
                txtCodigoServicio.setEditable(true);
                grpFechaServicio.setDisable(false);
                txtTipoServicio.setEditable(true);
                txtLugar.setEditable(true);
                tmpHora.setDisable(false);
                txtTelefono.setEditable(true);
                cmbCodigoEmpresa.setDisable(true);
                btnEliminar.setDisable(true);
                btnReporte.setDisable(true);
                btnEditar.setText("Guardar");
                tipoOperacion = Operacion.EDITAR;
                break;
            case EDITAR:
                editarServicio();
                cmbCodigoEmpresa.getSelectionModel().clearSelection();
                btnEditar.setText("Editar");
                tipoOperacion = Operacion.NINGUNO;
                break;
        }
    }
        
    public void btnCancelar(){
        txtCodigoServicio.setText("");
        txtTipoServicio.setText("");
        txtLugar.setText("");
        tmpHora.setValue(null);
        txtTelefono.setText("");
        fechaServicio.selectedDateProperty().set(null);
        cmbCodigoEmpresa.getSelectionModel().select(null);
        txtBuscar.setText(null);
        
        btnGuardar.setDisable(true);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(true);
        btnNuevo.setDisable(false);
        
        btnCancelar.setVisible(false);
    
        tipoOperacion = Operacion.NINGUNO;
        btnEditar.setText("Editar");
        
        desactivarTF();
        
        tblServicio.getSelectionModel().clearSelection();
    }
    
    public void guardarServicio(){
        if(fechaServicio.getSelectedDate() == null||txtTipoServicio.getText().isEmpty()||tmpHora.getValue() == null||txtTelefono.getText().isEmpty()||txtLugar.getText().isEmpty()||cmbCodigoEmpresa.getValue() == null){
            error.setTitle("ERROR");
            error.setContentText("El registro ha fallado!!\nFaltan datos por ingresar ó no es válido el tipo de dato");
            error.setHeaderText("Resultado:");
            error.show();            
        }else{
            Servicio registro = new Servicio();
            registro.setFecha_Servicio(fechaServicio.getSelectedDate());
            registro.setTipo_Servicio(txtTipoServicio.getText());
            registro.setHoraServicio(String.valueOf(tmpHora.getValue()));
            registro.setTelefonoContacto(txtTelefono.getText());
            registro.setLugarServicio(txtLugar.getText());
            registro.setCodigoEmpresa(((Empresa)cmbCodigoEmpresa.getSelectionModel().getSelectedItem()).getCodigoEmpresa());
            try {
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Agregar_Servicio(?,?,?,?,?,?)}");
                procedimiento.setDate(1, new java.sql.Date(registro.getFecha_Servicio().getTime()));
                procedimiento.setString(2, registro.getTipo_Servicio());
                procedimiento.setString(3, registro.getHoraServicio());
                procedimiento.setString(4, registro.getLugarServicio());
                procedimiento.setString(5, registro.getTelefonoContacto());
                procedimiento.setInt(6, registro.getCodigoEmpresa());
                procedimiento.execute();
                listaServicio.add(registro);
                if(registro != null){
                        informacion.setTitle("Registro agregado");
                        informacion.setContentText("El registro se ha completado con exito");
                        informacion.setHeaderText("Resultado:");
                        informacion.show();
                    cargarDatos();
                    desactivarTF();
                }
                Image imagen = new Image(getClass().getResourceAsStream("/org/josegongora/img/nuevo.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(imagen);//Cambiando la imagen del boton nuevo
                btnNuevo.setText("Nuevo");
                tipoOperacion = Operacion.NINGUNO;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public void editarServicio(){
        if(fechaServicio.getSelectedDate() == null||txtTipoServicio.getText().isEmpty()||tmpHora.getValue() == null||txtTelefono.getText().isEmpty()||txtLugar.getText().isEmpty()||cmbCodigoEmpresa.getValue() == null){
            error.setTitle("ERROR");
            error.setContentText("La modificación ha fallado!!\nFaltan datos por ingresar");
            error.setHeaderText("Resultado:");
            error.show();            
        }else{
            try {
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Actualizar_Servicio(?,?,?,?,?,?)}");
                procedimiento.setInt(1, Integer.parseInt(txtCodigoServicio.getText()));
                procedimiento.setDate(2, new java.sql.Date(fechaServicio.getSelectedDate().getTime()));
                procedimiento.setString(3, txtTipoServicio.getText());
                procedimiento.setString(4, String.valueOf(tmpHora.getValue()));
                procedimiento.setString(5, txtLugar.getText());
                procedimiento.setString(6, txtTelefono.getText());
                int res = procedimiento.executeUpdate();
                    if(res > 0){
                      informacion.setTitle("Registro Modificado");
                      informacion.setContentText("El registro se ha modificado con exito");
                      informacion.setHeaderText("Resultado:");
                      informacion.show();
                      grpFechaServicio.setDisable(true);
                      cargarDatos();
                    }else{
                      error.setTitle("Error");
                      error.setContentText("Error al intentar modificar el registro!!!");
                      error.setHeaderText("Resultado:");
                      error.show();
                      cargarDatos();
                    }     
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public void eliminarServicio(){
        confirmacion.setTitle("Eliminar Registro");
        confirmacion.setHeaderText("¿Estas seguro de eliminar este registro?\nSe eliminarán todos los registros relacionados con el Servicio");
        confirmacion.setContentText("Código: "+txtCodigoServicio.getText());
        Optional<ButtonType> opcion = confirmacion.showAndWait();
        if(opcion.get() == ButtonType.CANCEL){
           informacion.setTitle("Información");
           informacion.setContentText("Se ha cancelado el proceso.");
           informacion.setHeaderText("Resultado:");
           informacion.show();
           cargarDatos();
        }else if(opcion.get() == ButtonType.OK){
            try {
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Eliminar_Servicio(?)}");
                procedimiento.setInt(1, Integer.parseInt(txtCodigoServicio.getText()));
                int eli = procedimiento.executeUpdate();
                if(eli > 0){
                  informacion.setTitle("Registro Eliminado");
                  informacion.setContentText("El registro se ha eliminado con exito");
                  informacion.setHeaderText("Resultado:");
                  informacion.show();
                  fechaServicio.selectedDateProperty().set(null);
                  cargarDatos();
                }else{
                  error.setTitle("Error");
                  error.setContentText("Error al intentar eliminar registro!!!");
                  error.setHeaderText("Resultado:");
                  error.show();
                  cargarDatos();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }                 
        }
    }
    
    public void buscarDatos(){
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_Servicio(?)}");
            procedimiento.setString(1, txtBuscar.getText());
            ResultSet resultado = procedimiento.executeQuery();
            if(resultado.next()){
                txtCodigoServicio.setText(resultado.getString("codigoServicio"));
                fechaServicio.selectedDateProperty().set(resultado.getDate("fecha_Servicio"));
                txtTipoServicio.setText(resultado.getString("tipo_Servicio"));
                tmpHora.setValue(LocalTime.parse(resultado.getString("horaServicio")));
                txtLugar.setText(resultado.getString("lugarServicio"));
                txtTelefono.setText(resultado.getString("telefonoContacto"));
                cmbCodigoEmpresa.setValue(buscarEmpresa(resultado.getInt("codigoEmpresa")));
                desactivarBotones();
            }else{
                error.setTitle("ERROR");
                error.setHeaderText("Error:");
                error.setContentText("No existe un registro con codigo: "+txtBuscar.getText());
                error.show();
                txtBuscar.setText("");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    //Método para buscar servicio desde otra clase
    public Servicio buscarServicio(int codigoServicio){
        Servicio resultado = null;
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_Servicio(?)}");
            procedimiento.setInt(1, codigoServicio);
            ResultSet registro = procedimiento.executeQuery();
            while(registro.next()){
                resultado = new Servicio(registro.getInt("codigoServicio"),
                            registro.getDate("fecha_Servicio"),
                            registro.getString("tipo_Servicio"),
                            registro.getString("horaServicio"),
                            registro.getString("lugarServicio"),
                            registro.getString("telefonoContacto"),
                            registro.getInt("codigoEmpresa"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }
    
    //Método para limpiar Textfields y deshabilitar/habilitar botones 
    public void limpiarTF(){
        txtCodigoServicio.setText("");
        txtTipoServicio.setText("");
        txtLugar.setText("");
        //fechaServicio.selectedDateProperty().set(null);
        tmpHora.setValue(null);
        txtTelefono.setText("");
        cmbCodigoEmpresa.getSelectionModel().select(null);
        txtBuscar.setText(null);
        
        btnGuardar.setDisable(true);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(true);
        btnNuevo.setDisable(false);
        
        btnCancelar.setVisible(false);
        
    }
    
    //Método para limpiar datos pero con otras instrucciones
    public void limpiarDos(){
        txtCodigoServicio.setText("");
        txtTipoServicio.setText("");
        txtLugar.setText("");
        tmpHora.setValue(null);
        txtTelefono.setText("");
        //fechaServicio.selectedDateProperty().set(null);
        cmbCodigoEmpresa.getSelectionModel().select(null);
        txtBuscar.setText(null);
        
        btnGuardar.setDisable(false);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(true);
    }
    
    //Método para activar los TextField
    public void activarTF(){
        grpFechaServicio.setDisable(false);
        txtTipoServicio.setEditable(true);
        txtLugar.setEditable(true);
        tmpHora.setDisable(false);
        txtTelefono.setEditable(true);
        cmbCodigoEmpresa.setEditable(false);
        cmbCodigoEmpresa.setDisable(false);
    }
    
    //Método para desactivar los TextField
    public void desactivarTF(){
        //txtCodigoServicio.setEditable(false);
        grpFechaServicio.setDisable(true);
        txtTipoServicio.setEditable(false);
        txtLugar.setEditable(false);
        tmpHora.setDisable(true);
        txtTelefono.setEditable(false);
        cmbCodigoEmpresa.setDisable(true);
    }
    
    //Método para desactivar botones y hacer visible el boton cancelar
    public void desactivarBotones(){
        btnGuardar.setDisable(true);
        btnEditar.setDisable(false);
        btnEliminar.setDisable(false);
        btnReporte.setDisable(false);
        btnNuevo.setDisable(true);
        
        btnCancelar.setVisible(true);
    }
    
    //Método para comprobar la conexión a la base de datos
    public void estadoConexion(){
        try{
        if(Conexion.getInstance().getConexion() != null){
            informacion.setTitle("Conexión");
            informacion.setHeaderText("Resultado");
            informacion.setContentText("Conexion exitosa!!!");
            informacion.show();
        }else{
            error.setTitle("Conexión");
            error.setHeaderText("Resultado");
            error.setContentText("Error de conexión");
            error.show();
        }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void imprimirReporte(){
        Map parametros = new HashMap();
        int codServicio = Integer.valueOf(txtCodigoServicio.getText());
        parametros.put("codServicio", codServicio);
        GenerarReporte.mostrarReporte("ReporteServicios.jasper", "Reporte de Servicio", parametros);
        cargarDatos();
    }
    
    public void bloquearTamanioCol(){
        colCodigoServicio.setResizable(false);
        colFecha.setResizable(false);
        colHora.setResizable(false);
        colLugar.setResizable(false);
        colTelefono.setResizable(false);
        colTipo.setResizable(false);
        colCodigoEmpresa.setResizable(false);
        colCodigoServicio.reorderableProperty().set(false);
        colFecha.reorderableProperty().set(false);
        colHora.reorderableProperty().set(false);
        colLugar.reorderableProperty().set(false);
        colTelefono.reorderableProperty().set(false);
        colTipo.reorderableProperty().set(false);
        colCodigoEmpresa.reorderableProperty().set(false);
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cargarDatos();
        desactivarTF();
        seleccionServicio();
        bloquearTamanioCol();
        fechaServicio = new DatePicker(Locale.ENGLISH);
        fechaServicio.setDateFormat(new SimpleDateFormat("yyyy-MM-dd"));
        //fechaServicio.setBlendMode(BlendMode.COLOR_BURN);
        fechaServicio.setId("datePicker");
        fechaServicio.setPromptText("Fecha (yyyy-MM-dd)");
        fechaServicio.getCalendarView().todayButtonTextProperty().set("Hoy");
        fechaServicio.getCalendarView().setShowWeeks(false);
        fechaServicio.getStylesheets().add("org/josegongora/resources/DatePicker.css");
        grpFechaServicio.add(fechaServicio, 0, 0);
    }

    public MainApp getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(MainApp escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
    
    public void menuPrincipal(){
        escenarioPrincipal.menuPrincipal();
    }
}
