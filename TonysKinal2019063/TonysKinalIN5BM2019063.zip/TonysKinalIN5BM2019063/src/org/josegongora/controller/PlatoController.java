package org.josegongora.controller;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import org.josegongora.bd.Conexion;
import org.josegongora.bean.Plato;
import org.josegongora.bean.TipoPlato;
import org.josegongora.system.MainApp;


public class PlatoController implements Initializable{
    private MainApp escenarioPrincipal;
    
    private enum Operacion{NUEVO,GUARDAR,ELIMINAR,EDITAR,CARGAR,NINGUNO}
    private Operacion tipoOperacion = Operacion.NINGUNO;
    
    ObservableList<Plato> listaPlato;
    
    ObservableList<TipoPlato> listaTipoPlato;
    
    @FXML private TableView tblPlato;
    
    @FXML private TableColumn colCodigoPlato, colCantidadPlato, colNombrePlato, colDescripcionPlato, colPrecioPlato, colCodigoTipoPlato;
    
    @FXML private JFXComboBox cmbCodigoTipoPlato;
    
    @FXML private JFXButton btnNuevo, btnGuardar, btnEditar, btnEliminar, btnCancelar, btnReporte;
    
    @FXML private TextField txtBuscar;
    
    @FXML private ImageView imgNuevo;
    
    @FXML private JFXTextField txtCodigoPlato, txtCantidadPlato, txtNombrePlato, txtDescripcionPlato, txtPrecioPlato;
    
    Alert error = new Alert(AlertType.ERROR); //Creando objetos de tipo Alert para utilizar en toda la clase
    Alert informacion = new Alert(AlertType.INFORMATION);//Creando objetos de tipo Alert para utilizar en toda la clase
    Alert confirmacion  = new Alert(AlertType.CONFIRMATION);//Creando objetos de tipo Alert para utilizar en toda la clase
    
    public void cargarDatos(){
        tblPlato.setItems(getPlato());
        colCodigoPlato.setCellValueFactory(new PropertyValueFactory<Plato, Integer>("codigoPlato"));
        colCantidadPlato.setCellValueFactory(new PropertyValueFactory<Plato, Integer>("cantidad"));
        colNombrePlato.setCellValueFactory(new PropertyValueFactory<Plato, String>("nombrePlato"));
        colDescripcionPlato.setCellValueFactory(new PropertyValueFactory<Plato, String>("descripcionPlato"));
        colPrecioPlato.setCellValueFactory(new PropertyValueFactory<Plato, Double>("precioPlato"));
        colCodigoTipoPlato.setCellValueFactory(new PropertyValueFactory<Plato, Integer>("codigoTipoPlato"));
        cmbCodigoTipoPlato.setEditable(true);
        cmbCodigoTipoPlato.setItems(getTipoPlato());
        limpiarTF();
        tblPlato.getSelectionModel().clearSelection();
    }
    
    public void seleccionPlato(){
        tblPlato.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Plato>(){
            @Override
            public void changed(ObservableValue<? extends Plato> observable, Plato valorAnterior, Plato valorSeleccionado) {
                if(valorSeleccionado != null){
                    txtCodigoPlato.setText(String.valueOf(valorSeleccionado.getCodigoPlato()));
                    txtCantidadPlato.setText(String.valueOf(valorSeleccionado.getCantidad()));
                    txtNombrePlato.setText(valorSeleccionado.getNombrePlato());
                    txtDescripcionPlato.setText(valorSeleccionado.getDescripcionPlato());
                    txtPrecioPlato.setText(String.valueOf(valorSeleccionado.getPrecioPlato()));
                    cmbCodigoTipoPlato.setValue(buscarTipoPlato(valorSeleccionado.getCodigoTipoPlato()));
                    desactivarBotones();
                    desactivarTF();
                }
            }
            
        });
    }
    
    public ObservableList<Plato> getPlato(){
        ArrayList<Plato> lista = new ArrayList<Plato>();
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Listar_Plato()}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new Plato(resultado.getInt("codigoPlato"),
                                    resultado.getInt("cantidad"),
                                    resultado.getString("nombrePlato"),
                                    resultado.getString("descripcionPlato"),
                                    resultado.getDouble("precioPlato"),
                                    resultado.getInt("codigoTipoPlato")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaPlato = FXCollections.observableArrayList(lista);
    }
    
    public ObservableList<TipoPlato> getTipoPlato(){
        ArrayList<TipoPlato> lista = new ArrayList<TipoPlato>();
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Listar_Tipo_Plato()}");
            ResultSet resultado = procedimiento.executeQuery();
            while(resultado.next()){
                lista.add(new TipoPlato(resultado.getInt("codigoTipoPlato"),
                                        resultado.getString("descripcionTipo")));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaTipoPlato = FXCollections.observableArrayList(lista);
    }
    
    public TipoPlato buscarTipoPlato(int codigoTipoPlato){
        TipoPlato resultado = null;
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_Tipo_Plato(?)}");
            procedimiento.setInt(1, codigoTipoPlato);
            ResultSet registro = procedimiento.executeQuery();
            while(registro.next()){
                resultado = new TipoPlato(registro.getInt("codigoTipoPlato"),
                                      registro.getString("descripcionTipo"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }
    
    public void buscarDatos(){
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_Plato(?)}");
            procedimiento.setString(1, txtBuscar.getText());
            ResultSet resultado = procedimiento.executeQuery();
            if(resultado.next()){
                txtCodigoPlato.setText(resultado.getString("codigoPlato"));
                txtCantidadPlato.setText(String.valueOf(resultado.getInt("cantidad")));
                txtNombrePlato.setText(resultado.getString("nombrePlato"));
                txtDescripcionPlato.setText(resultado.getString("descripcionPlato"));
                txtPrecioPlato.setText(String.valueOf(resultado.getDouble("precioPlato")));
                cmbCodigoTipoPlato.setValue(buscarTipoPlato(resultado.getInt("codigoTipoPlato")));
                desactivarBotones();
            }else{
                error.setTitle("ERROR");
                error.setHeaderText("Error:");
                error.setContentText("No existe un registro con codigo: "+txtBuscar.getText());
                error.show();
                txtBuscar.setText("");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public Plato buscarPlato(int codigoPlato){
        Plato resultado = null;
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Buscar_Plato(?)}");
            procedimiento.setInt(1, codigoPlato);
            ResultSet registro = procedimiento.executeQuery();
            while(registro.next()){
                resultado = new Plato(registro.getInt("codigoPlato"),
                                    registro.getInt("cantidad"),
                                    registro.getString("nombrePlato"),
                                    registro.getString("descripcionPlato"),
                                    registro.getDouble("precioPlato"),
                                    registro.getInt("codigoTipoPlato"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultado;
    }
    
    public void btnNuevo(){
        switch(tipoOperacion){
            case NINGUNO:
                Image img = new Image(getClass().getResourceAsStream("/org/josegongora/img/cancelar.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(img);//Cambiando la imagen del boton nuevo
                btnGuardar.setDisable(false);
                btnNuevo.setText("Cancelar");
                activarTF();
                limpiarDos();
                tipoOperacion = Operacion.GUARDAR;
                break;
            case GUARDAR:
                Image imagen = new Image(getClass().getResourceAsStream("/org/josegongora/img/nuevo.png"));//Creando un objeto de tipo Image
                imgNuevo.setImage(imagen);//Cambiando la imagen del boton nuevo
                btnGuardar.setDisable(true);
                btnNuevo.setText("Nuevo");
                limpiarTF();
                desactivarTF();
                cargarDatos();
                tipoOperacion = Operacion.NINGUNO;
                break;
        }
    }
    
    public void btnEditar(){
        switch(tipoOperacion){
            case NINGUNO:
                txtCantidadPlato.setEditable(true);
                txtNombrePlato.setEditable(true);
                txtDescripcionPlato.setEditable(true);
                txtPrecioPlato.setEditable(true);
                cmbCodigoTipoPlato.setDisable(true);
                btnEliminar.setDisable(true);
                btnReporte.setDisable(true);
                btnEditar.setText("Guardar");
                tipoOperacion = Operacion.EDITAR;
                break;
            case EDITAR:
                editarDato();
                cmbCodigoTipoPlato.getSelectionModel().clearSelection();
                btnEditar.setText("Editar");
                tipoOperacion = Operacion.NINGUNO;
                break;
        }
    }
    
    public void btnCancelar(){
        txtCodigoPlato.setText("");
        txtCantidadPlato.setText("");
        txtNombrePlato.setText("");
        txtDescripcionPlato.setText("");
        txtPrecioPlato.setText("");
        cmbCodigoTipoPlato.getSelectionModel().select(null);

        txtBuscar.setText(null);
        
        btnGuardar.setDisable(true);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(false);
        btnNuevo.setDisable(false);
        
        btnCancelar.setVisible(false);
    
        tipoOperacion = Operacion.NINGUNO;
        btnEditar.setText("Editar");
        
        desactivarTF();
        
        tblPlato.getSelectionModel().clearSelection();
    }
    
    public void guardarDato(){
        if(txtCantidadPlato.getText().isEmpty()||txtNombrePlato.getText().isEmpty()||txtDescripcionPlato.getText().isEmpty()||txtPrecioPlato.getText().isEmpty()||cmbCodigoTipoPlato.getValue() == null){
            error.setTitle("ERROR");
            error.setContentText("El registro ha fallado!!\nFaltan datos por ingresar");
            error.setHeaderText("Resultado:");
            error.show();           
        }else{
            Plato registro = new Plato();
            registro.setCantidad(Integer.parseInt(txtCantidadPlato.getText()));
            registro.setNombrePlato(txtNombrePlato.getText());
            registro.setDescripcionPlato(txtDescripcionPlato.getText());
            registro.setPrecioPlato(Double.parseDouble(txtPrecioPlato.getText()));
            registro.setCodigoTipoPlato(((TipoPlato)cmbCodigoTipoPlato.getSelectionModel().getSelectedItem()).getCodigoTipoPlato());
                try {
                    PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Agregar_Plato(?,?,?,?,?)}");
                    procedimiento.setInt(1, registro.getCantidad());
                    procedimiento.setString(2, registro.getNombrePlato());
                    procedimiento.setString(3, registro.getDescripcionPlato());
                    procedimiento.setDouble(4, registro.getPrecioPlato());
                    procedimiento.setInt(5, registro.getCodigoTipoPlato());
                    procedimiento.executeUpdate();
                    listaPlato.add(registro);
                    if(registro != null){
                        informacion.setTitle("Registro agregado");
                        informacion.setContentText("El registro se ha completado con exito");
                        informacion.setHeaderText("Resultado:");
                        informacion.show();
                        cargarDatos();
                        desactivarTF();
                    }
                    Image imagen = new Image(getClass().getResourceAsStream("/org/josegongora/img/nuevo.png"));//Creando un objeto de tipo Image
                    imgNuevo.setImage(imagen);//Cambiando la imagen del boton nuevo
                    btnNuevo.setText("Nuevo");
                    tipoOperacion = Operacion.NINGUNO;
                } catch (Exception e) {
                    e.printStackTrace();
                }
        }
    }
    
    public void eliminarDato(){
        confirmacion.setTitle("Eliminar Registro");
        confirmacion.setHeaderText("¿Estas seguro de eliminar este registro?\nSe eliminarán todos los registros relacionados con el Plato");
        confirmacion.setContentText("Código: "+txtCodigoPlato.getText());
        Optional<ButtonType> opcion = confirmacion.showAndWait();
        if(opcion.get() == ButtonType.CANCEL){
           informacion.setTitle("Información");
           informacion.setContentText("Se ha cancelado el proceso.");
           informacion.setHeaderText("Resultado:");
           informacion.show();
           cargarDatos();
        }else if(opcion.get() == ButtonType.OK){
            try {
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Eliminar_Plato(?)}");
                procedimiento.setInt(1, Integer.parseInt(txtCodigoPlato.getText()));
                int eli = procedimiento.executeUpdate();
                if(eli > 0){
                  informacion.setTitle("Registro Eliminado");
                  informacion.setContentText("El registro se ha eliminado con exito");
                  informacion.setHeaderText("Resultado:");
                  informacion.show();
                  cargarDatos();
                }else{
                  error.setTitle("Error");
                  error.setContentText("Error al intentar eliminar registro!!!");
                  error.setHeaderText("Resultado:");
                  error.show();
                  cargarDatos();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }                 
        }
    }
    
    public void editarDato(){
        if(txtCantidadPlato.getText().isEmpty()||txtNombrePlato.getText().isEmpty()||txtDescripcionPlato.getText().isEmpty()||txtPrecioPlato.getText().isEmpty()||cmbCodigoTipoPlato.getValue() == null){
            error.setTitle("ERROR");
            error.setContentText("La modificación ha fallado!!\nFaltan datos por ingresar");
            error.setHeaderText("Resultado:");
            error.show();           
        }else{
            try {
                PreparedStatement procedimiento = Conexion.getInstance().getConexion().prepareCall("{call sp_Actualizar_Plato(?,?,?,?,?)}");
                procedimiento.setInt(1, Integer.parseInt(txtCodigoPlato.getText()));
                procedimiento.setInt(2, Integer.parseInt(txtCantidadPlato.getText()));
                procedimiento.setString(3, txtNombrePlato.getText());
                procedimiento.setString(4, txtDescripcionPlato.getText());
                procedimiento.setDouble(5, Double.parseDouble(txtPrecioPlato.getText()));
                int res = procedimiento.executeUpdate();
                if(res > 0){
                    informacion.setTitle("Registro Modificado");
                    informacion.setContentText("El registro se ha modificado con exito");
                    informacion.setHeaderText("Resultado:");
                    informacion.show();
                    cargarDatos();
                }else{
                    error.setTitle("Error");
                    error.setContentText("Error al intentar modificar el registro!!!");
                    error.setHeaderText("Resultado:");
                    error.show();
                    cargarDatos();
                }     
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    //Método para limpiar Textfields y deshabilitar/habilitar botones 
    public void limpiarTF(){
        txtCodigoPlato.setText("");
        txtCantidadPlato.setText("");
        txtNombrePlato.setText("");
        txtDescripcionPlato.setText("");
        txtPrecioPlato.setText("");
        cmbCodigoTipoPlato.getSelectionModel().clearSelection();
        txtBuscar.setText(null);
        
        btnGuardar.setDisable(true);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(false);
        btnNuevo.setDisable(false);
        
        btnCancelar.setVisible(false);
        
    }
    
    //Método para limpiar datos pero con otras instrucciones
    public void limpiarDos(){
        txtCodigoPlato.setText("");
        txtCantidadPlato.setText("");
        txtNombrePlato.setText("");
        txtDescripcionPlato.setText("");
        txtPrecioPlato.setText("");
        cmbCodigoTipoPlato.getSelectionModel().clearSelection();
        txtBuscar.setText(null);
        
        btnGuardar.setDisable(false);
        btnEditar.setDisable(true);
        btnEliminar.setDisable(true);
        btnReporte.setDisable(true);
    }
    
    //Método para activar los TextField
    public void activarTF(){
        txtCantidadPlato.setEditable(true);
        txtNombrePlato.setEditable(true);
        txtDescripcionPlato.setEditable(true);
        txtPrecioPlato.setEditable(true);
        cmbCodigoTipoPlato.setDisable(false);
        cmbCodigoTipoPlato.setEditable(false);
    }
    
    //Método para desactivar los TextField
    public void desactivarTF(){
        txtCantidadPlato.setEditable(false);
        txtNombrePlato.setEditable(false);
        txtDescripcionPlato.setEditable(false);
        txtPrecioPlato.setEditable(false);
        cmbCodigoTipoPlato.setDisable(true);
    }
    
    //Método para desactivar botones y hacer visible el boton cancelar
    public void desactivarBotones(){
        btnGuardar.setDisable(true);
        btnEditar.setDisable(false);
        btnEliminar.setDisable(false);
        btnReporte.setDisable(true);
        btnNuevo.setDisable(true);
        
        btnCancelar.setVisible(true);
    }
    
    //Método para comprobar la conexión a la base de datos
    public void estadoConexion(){
        try{
        if(Conexion.getInstance().getConexion() != null){
            informacion.setTitle("Conexión");
            informacion.setHeaderText("Resultado");
            informacion.setContentText("Conexion exitosa!!!");
            informacion.show();
        }else{
            error.setTitle("Conexión");
            error.setHeaderText("Resultado");
            error.setContentText("Error de conexión");
            error.show();
        }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public void bloquearTamanioCol(){
        colCodigoPlato.setResizable(false);
        colCantidadPlato.setResizable(false);
        colNombrePlato.setResizable(false);
        colDescripcionPlato.setResizable(false);
        colPrecioPlato.setResizable(false);
        colCodigoTipoPlato.setResizable(false);
        colCodigoPlato.reorderableProperty().set(false);
        colCantidadPlato.reorderableProperty().set(false);
        colNombrePlato.reorderableProperty().set(false);
        colDescripcionPlato.reorderableProperty().set(false);
        colPrecioPlato.reorderableProperty().set(false);
        colCodigoTipoPlato.reorderableProperty().set(false);
    }
    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cargarDatos();
        seleccionPlato();
        desactivarTF();
        bloquearTamanioCol();
    }

    public MainApp getEscenarioPrincipal() {
        return escenarioPrincipal;
    }

    public void setEscenarioPrincipal(MainApp escenarioPrincipal) {
        this.escenarioPrincipal = escenarioPrincipal;
    }
    
    public void menuPrincipal(){
        escenarioPrincipal.menuPrincipal();
    }
    
}
